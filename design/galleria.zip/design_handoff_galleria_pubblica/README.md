# Handoff: Galleria pubblica (annuncio stanza/casa)

## Overview
Pagina pubblica, senza autenticazione, che presenta la casa/stanza in affitto: foto organizzate per stanza, planimetria (esportata da Floorplanner), e informazioni su posizione/raggiungibilità. Pensata sia per candidati futuri inquilini (tipo annuncio) sia come vetrina "prima" dell'accesso autenticato all'app Viapal. Non è linkata dalla navigazione interna dell'app: è l'unica area pubblica.

## About the Design Files
I file in questo bundle sono **riferimenti di design in HTML** — prototipi che mostrano aspetto e comportamento previsti, non codice di produzione da copiare direttamente. Il compito è **ricreare questi design HTML nell'ambiente/stack già esistente del progetto di destinazione** (React, Vue, ecc.) usandone i pattern consolidati — oppure, se non esiste ancora uno stack, scegliere il framework più adatto e implementare lì.

## Fidelity
**Alta fedeltà (hifi)**: colori, tipografia, spaziature e layout sono definitivi (vedi `tokens.css`). Le foto sono attualmente drag-and-drop placeholder (componente prototipale `image-slot.js`) — **vanno sostituite con un vero sistema di upload/gestione immagini** lato produzione (vedi sezione "Punto aperto" sotto).

## Punto aperto — upload immagini
Nel prototipo le foto si caricano trascinandole su placeholder (`<image-slot>`), che salvano localmente in un file di supporto usato solo nell'ambiente di prototipazione. **Questo meccanismo non è adatto alla produzione** ed è anzi risultato inaffidabile per immagini multiple/pesanti in fase di prototipo. In produzione serve un vero flusso di upload:
- Upload verso storage reale (S3/Cloud Storage/equivalente), con resize/compressione server-side.
- Associazione immagine ↔ stanza ↔ ordine di visualizzazione, persistita in DB.
- Stati: slot vuoto (placeholder), caricamento, errore upload, immagine caricata.
- Chi carica: presumibilmente il proprietario/gestore dell'alloggio da un'area amministrativa (non il pubblico che visita la pagina).

## Screens / Views

### Galleria pubblica (`Galleria.html`)
Singola pagina scrollabile, sezioni in ordine:

1. **Header pubblico** — sticky, altezza 64px, sfondo semi-trasparente con blur. Logo/wordmark "Viapal · annuncio" a sinistra, bottone ghost "Come arrivare" a destra (anchor a #posizione).

2. **Hero** — altezza 78vh (min 460px, max 720px). Foto full-bleed (`image-slot` shape rect) con scrim scuro sfumato dal basso. Sovrapposti in basso: eyebrow ("Stanza in condivisione · disponibile"), titolo H1 (serif display, clamp 30–52px), indirizzo indicativo, riga di 4 "fact" (mq totali, camere, bagni, posti letto — numero in mono bold + etichetta piccola). CTA primario in basso a destra ("Richiedi informazioni").

3. **Pill nav** — riga di pillole orizzontali scrollabili: Planimetria, una per stanza, Posizione. Le stanze non disponibili hanno la pillola con opacità ridotta (classe `.is-unavail`) e testo "· occupata".

4. **Planimetria** — grid 2 colonne (1.5fr / 1fr) desktop, 1 colonna mobile. Sinistra: `image-slot` per l'immagine planimetria (aspect-ratio 4:3, radius 16px). Destra: legenda cliccabile — righe con numero colorato (cerchio 26px), nome stanza, badge "Occupata" se non disponibile, mq in mono. Ogni riga è un link `#id-stanza`.

5. **Sezioni stanza** (una per stanza, generate da un array `ROOMS`) — separate da bordo superiore. Header: pallino colore identificativo, nome stanza (serif 24px), pill mq, badge "Non disponibile" (arancio/clay) se applicabile. Descrizione breve. Griglia foto: CSS grid 4 colonne, la prima cella più grande (span 2×2), righe auto 150px, gap 10px; ogni foto ha un pulsante "espandi" in basso a destra che apre una lightbox full-screen. **Se la stanza non è disponibile, la griglia foto è sostituita da un box centrato con nota "Foto non disponibili — stanza attualmente occupata"** (nessun placeholder foto mostrato).

6. **Posizione & raggiungibilità** — grid 2 colonne (1 su mobile). Sinistra: `image-slot` per screenshot mappa (altezza 340px, radius 16). Destra: 4 card info (icona + titolo + testo): Indirizzo, Mezzi pubblici (con chip tempi/linee), Parcheggio & note pratiche, Regole della casa (no fumo, no animali).

7. **Footer** — testo centrato, nota "Pagina pubblica · nessun accesso richiesto".

**Lightbox**: overlay full-screen (rgba scuro 92%), immagine centrata max-width/height 100%, bottone chiusura cerchio in alto a destra. Si apre cliccando l'icona espandi su una foto; si chiude cliccando il bottone o fuori dall'immagine.

## Interactions & Behavior
- Anchor links (pill nav, legenda planimetria, CTA "Come arrivare") — scroll nativo del browser verso l'id sezione, nessuna animazione custom.
- Lightbox: click su pulsante espandi apre `<img>` a piena risoluzione della foto della cella; click fuori o sulla X chiude.
- Hover pillole/legenda: leggero cambio di sfondo/colore (vedi tokens sotto).
- Nessuna form di contatto implementata: il CTA "Richiedi informazioni" e il link "Come arrivare" sono placeholder di navigazione — va definito il flusso di contatto reale (form, mailto, integrazione CRM, ecc.).
- Stato "non disponibile" per stanza: booleano `available:false` nell'array dati, guida sia lo stile (opacità, badge) sia il contenuto (niente foto, nota testuale).

## State Management
Dati statici in un array JS `ROOMS` (id, nome, mq, colore, descrizione, numero foto, disponibilità). In produzione questo diventa il modello dati "stanza" letto da API/DB, con relazione a immagini caricate e stato disponibilità aggiornabile da chi gestisce l'alloggio.

## Design Tokens
Da `tokens.css` (sistema Viapal, direzione "Materica" — terra/legno/salvia):

**Colori base**
- Sfondo principale: `--vp-paper` oklch(0.975 0.012 75)
- Card/sfondo secondario: `--vp-paper-2` oklch(0.945 0.018 75), `--vp-paper-3` oklch(0.91 0.022 75)
- Card primaria/bianco: `--vp-cream` oklch(0.985 0.008 80)
- Testo: `--vp-ink` oklch(0.26 0.022 50) primario, `--vp-ink-2` oklch(0.42 0.020 55) secondario, `--vp-ink-3` oklch(0.58 0.018 60) terziario

**Accenti**
- Terracotta (primario/CTA): `--vp-terra` oklch(0.62 0.115 38), hover `--vp-terra-deep` oklch(0.45 0.105 35), tenue `--vp-terra-soft` oklch(0.88 0.045 40)
- Salvia (positivo): `--vp-sage` oklch(0.58 0.055 145)
- Miele (attesa): `--vp-honey` oklch(0.72 0.105 75)
- Argilla (non disponibile/errore): `--vp-clay` oklch(0.55 0.110 25), tenue `--vp-clay-soft` oklch(0.90 0.035 28)

**Tipografia**
- Display (titoli): Source Serif 4 → Georgia, serif
- UI (corpo): Geist → IBM Plex Sans, system-ui, sans-serif
- Mono (numeri/mq): Geist Mono → IBM Plex Mono, monospace
- Scale: 12/13/15/17/20/26/34/44/56px

**Radius**: 8 / 12 / 18 / 24px, pill 9999px
**Shadow**: 3 livelli morbidi, mai nere dure (vedi `--vp-shadow-1/2/3` in tokens.css)

## Assets
- Foto stanze/hero/mappa/planimetria: attualmente placeholder drag-and-drop, da sostituire con foto reali caricate dal proprietario.
- Icone: inline SVG stroke 1.6, disegnate ad hoc (pin, bus, auto, regole/casa, espandi) — stile lineare coerente col resto del sistema icone Viapal.

## Files
- `Galleria.html` — pagina completa (HTML/CSS/JS inline)
- `tokens.css` — design tokens del sistema Viapal (condiviso con il resto dell'app)
