/* global React, VPIcon, VPLeaf, VPHouse, VPAvatar, VPEnvelope */

// ── Prototipo 4: Calcolo conguaglio bollette (desktop) ────────
// Tre viste distinte: Bolletta · Ripartizione · Invio.

// Anagrafica utenze del periodo (dati realistici dal flusso reale)
const CG_BILLS = [
  { tipo:'Luce', icon:'bolt',  fornitore:'Enel Energia', importo:194.91, periodo:'01/03 – 31/03', consumo:'287 kWh', rif:'POD IT001E94…', hue:78 },
  { tipo:'Gas',  icon:'flame', fornitore:'ENI',          importo:27.02,  periodo:'01/03 – 31/03', consumo:'18 Smc',  rif:'PDR 00980…',    hue:250 },
  { tipo:'TARI', icon:'trash', fornitore:'Comune',       importo:44.58,  periodo:'1° trim. 2026', consumo:'—',       rif:'Ruolo 2026',    hue:150 },
];
const CG_TOT = CG_BILLS.reduce((s,b)=>s+b.importo,0);

const CG_COLORS = {
  Luce: { fg:'oklch(0.50 0.10 78)',  soft:'oklch(0.93 0.05 82)',  bar:'oklch(0.72 0.105 78)' },
  Gas:  { fg:'oklch(0.46 0.07 250)', soft:'oklch(0.93 0.035 250)',bar:'oklch(0.62 0.08 250)' },
  TARI: { fg:'oklch(0.42 0.055 150)',soft:'oklch(0.90 0.03 150)', bar:'oklch(0.58 0.055 150)' },
};

const CG_INQ = [
  { nome:'Marco',  stanza:'Salvia',   mq:14, giorni:31, email:'marco.b@gmail.com',     entrata:null },
  { nome:'Sara',   stanza:'Olmo',     mq:18, giorni:31, email:'sara.conti@gmail.com',  entrata:null },
  { nome:'Leila',  stanza:'Tiglio',   mq:12, giorni:31, email:'leila.h@icloud.com',    entrata:null },
  { nome:'Yusuf',  stanza:'Acero',    mq:16, giorni:31, email:'yusuf.k@gmail.com',     entrata:null },
  { nome:'Anna',   stanza:'Ciliegio', mq:15, giorni:18, email:'anna.r@gmail.com',      entrata:'14 marzo' },
];
const CG_HUE = [20, 95, 150, 250, 330];
const eur = n => '€ ' + n.toLocaleString('it-IT', { minimumFractionDigits:2, maximumFractionDigits:2 });

// Periodi: storico inviato + il corrente da inviare + il futuro con bollette mancanti
const CG_PERIODI = [
  { id:'2025-12', mese:'dicembre',  label:'Dicembre 2025', range:'01/12 – 31/12', stato:'inviato',    presenti:3, attese:3 },
  { id:'2026-01', mese:'gennaio',   label:'Gennaio 2026',  range:'01/01 – 31/01', stato:'inviato',    presenti:3, attese:3 },
  { id:'2026-02', mese:'febbraio',  label:'Febbraio 2026', range:'01/02 – 28/02', stato:'inviato',    presenti:3, attese:3 },
  { id:'2026-03', mese:'marzo',     label:'Marzo 2026',    range:'01/03 – 31/03', stato:'da-inviare', presenti:3, attese:3 },
  { id:'2026-04', mese:'aprile',    label:'Aprile 2026',   range:'01/04 – 30/04', stato:'incompleto', presenti:1, attese:3 },
];
// Default: l'ultimo (più recente) periodo NON ancora inviato o con bollette mancanti.
function cgDefaultPeriodo() {
  const aperti = CG_PERIODI.filter(p => p.stato !== 'inviato');
  return (aperti[aperti.length-1] || CG_PERIODI[CG_PERIODI.length-1]).id;
}

function cgComputeQuote(criterio) {
  const totMq = CG_INQ.reduce((s,i)=>s+i.mq,0);
  const totG  = CG_INQ.reduce((s,i)=>s+i.giorni,0);
  const n = CG_INQ.length;
  const share = (importo, i) => {
    if (criterio==='teste') return importo / n;
    if (criterio==='mq')    return importo * i.mq / totMq;
    return importo * i.giorni / totG;
  };
  return CG_INQ.map((i, idx) => {
    const per = {};
    CG_BILLS.forEach(b => { per[b.tipo] = share(b.importo, i); });
    const quota = Object.values(per).reduce((s,v)=>s+v,0);
    return { ...i, hue: CG_HUE[idx], per, quota };
  });
}

function ProtoConguaglio({ initialStep = 1, periodo }) {
  const [step, setStep] = React.useState(initialStep); // 1 Bolletta · 2 Ripartizione · 3 Invio
  const [criterio, setCriterio] = React.useState('giorni');
  const [openMsg, setOpenMsg] = React.useState(1);
  const [periodoId, setPeriodoId] = React.useState(periodo || cgDefaultPeriodo());
  const [perOpen, setPerOpen] = React.useState(false);
  const per = CG_PERIODI.find(p => p.id === periodoId) || CG_PERIODI[CG_PERIODI.length-1];
  const incompleto = per.stato === 'incompleto';
  const mancanti = per.attese - per.presenti;
  const quote = React.useMemo(() => cgComputeQuote(criterio), [criterio]);
  const sommaQuote = quote.reduce((s,q)=>s+q.quota,0);

  const STEPS = ['Bolletta','Ripartizione','Invio'];
  const LAST = STEPS.length;

  return (
    <div style={{width:'100%',height:'100%',display:'flex',flexDirection:'column',background:'var(--vp-paper)',color:'var(--vp-ink)',fontFamily:'var(--vp-font-ui)'}}>
      {/* ── Intestazione fissa ─────────────────────────── */}
      <div style={{padding:'18px 36px 0',flexShrink:0}}>
        <div style={{display:'flex',alignItems:'center',gap:8,fontSize:13,color:'var(--vp-ink-3)'}}>
          <span>Utenze &amp; conguagli</span>
          <VPIcon name="chevron" size={12}/>
          <span style={{color:'var(--vp-ink)'}}>{per.label}</span>
        </div>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-end',margin:'8px 0 16px',flexWrap:'wrap',gap:12}}>
          <div>
            <h1 className="vp-display" style={{fontSize:30,margin:0}}>Conguaglio utenze, <span style={{color:'var(--vp-ink-2)',fontStyle:'italic'}}>{per.mese}</span></h1>
            <div style={{color:'var(--vp-ink-2)',fontSize:14,marginTop:4}}>Periodo {per.range} · {CG_INQ.length} inquilini · pagata da Alessandro Dentella</div>
          </div>

          {/* Selettore periodo */}
          <div style={{position:'relative'}}>
            <div className="vp-eyebrow" style={{marginBottom:4}}>Periodo</div>
            <button onClick={()=>setPerOpen(o=>!o)} style={{
              display:'flex',alignItems:'center',gap:10,padding:'9px 14px',borderRadius:11,cursor:'pointer',
              background:'var(--vp-paper-2)',border:'1.5px solid var(--vp-paper-3)',fontFamily:'inherit',
              color:'var(--vp-ink)',minWidth:210,
            }}>
              <VPIcon name="calendar" size={16} color="var(--vp-terra)"/>
              <span style={{flex:1,textAlign:'left',fontWeight:600,fontSize:15}}>{per.label}</span>
              <CGStatoBadge per={per} compact/>
              <VPIcon name="chevron" size={15} color="var(--vp-ink-3)" style={{transform:perOpen?'rotate(90deg)':'none',transition:'transform .15s'}}/>
            </button>
            {perOpen && (
              <div style={{
                position:'absolute',right:0,top:'100%',marginTop:6,zIndex:20,width:300,
                background:'var(--vp-paper)',border:'1px solid var(--vp-paper-3)',borderRadius:14,
                boxShadow:'var(--vp-shadow-3)',overflow:'hidden',
              }}>
                <div style={{padding:'10px 14px',fontSize:12,color:'var(--vp-ink-3)',borderBottom:'1px solid var(--vp-paper-3)'}}>
                  Si apre sull’ultimo periodo da completare
                </div>
                {[...CG_PERIODI].reverse().map(p => {
                  const sel = p.id===periodoId;
                  return (
                    <button key={p.id} onClick={()=>{setPeriodoId(p.id);setPerOpen(false);setStep(1);}} style={{
                      width:'100%',display:'flex',alignItems:'center',gap:10,padding:'11px 14px',
                      background:sel?'var(--vp-cream)':'transparent',border:'none',cursor:'pointer',
                      borderLeft:`3px solid ${sel?'var(--vp-terra)':'transparent'}`,fontFamily:'inherit',
                      color:'var(--vp-ink)',textAlign:'left',
                    }}>
                      <div style={{flex:1}}>
                        <div style={{fontSize:14,fontWeight:sel?600:500}}>{p.label}</div>
                        <div style={{fontSize:12,color:'var(--vp-ink-3)'}}>{p.range}</div>
                      </div>
                      <CGStatoBadge per={p}/>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Stepper cliccabile */}
        <div style={{display:'flex',gap:10}}>
          {STEPS.map((l,i) => {
            const n = i+1, done = n<step, active = n===step;
            const locked = incompleto && n>1;
            return (
              <button key={i} disabled={locked} onClick={()=>!locked&&setStep(n)} style={{
                flex:1,padding:'11px 16px',borderRadius:12,cursor:locked?'not-allowed':'pointer',textAlign:'left',
                background: active?'var(--vp-cream)':done?'var(--vp-sage-soft)':'var(--vp-paper-2)',
                border:`1.5px solid ${active?'var(--vp-terra)':'transparent'}`,
                display:'flex',alignItems:'center',gap:11,fontFamily:'inherit',opacity:locked?.5:1,
                color: active?'var(--vp-ink)':done?'var(--vp-sage-deep)':'var(--vp-ink-3)',
                transition:'background .15s, border-color .15s',
              }}>
                <div style={{
                  width:24,height:24,borderRadius:'50%',flexShrink:0,
                  background: done?'var(--vp-sage)':active?'var(--vp-terra)':'var(--vp-paper-3)',
                  color: done||active?'#fff':'var(--vp-ink-3)',
                  display:'flex',alignItems:'center',justifyContent:'center',fontSize:13,fontWeight:600,
                }}>{done ? <VPIcon name="check" size={13} stroke={3} color="#fff"/> : locked ? <VPIcon name="lock" size={12} color="var(--vp-ink-3)"/> : n}</div>
                <div>
                  <div style={{fontSize:11,letterSpacing:'0.06em',textTransform:'uppercase',opacity:.7,fontWeight:500}}>Passo {n}</div>
                  <div style={{fontSize:15,fontWeight:active?600:500,marginTop:1}}>{l}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* ── Corpo scrollabile della vista attiva ───────── */}
      <div className="vp-scroll" style={{flex:1,minHeight:0,overflow:'auto',padding:'20px 36px 96px'}}>
        {step===1 && <CGBolletta per={per} incompleto={incompleto} mancanti={mancanti}/>}
        {step===2 && (incompleto ? <CGBloccato mancanti={mancanti}/> : <CGRipartizione criterio={criterio} setCriterio={setCriterio} quote={quote} sommaQuote={sommaQuote}/>)}
        {step===3 && (incompleto ? <CGBloccato mancanti={mancanti}/> : <CGInvio quote={quote} criterio={criterio} openMsg={openMsg} setOpenMsg={setOpenMsg} per={per}/>)}
      </div>

      {/* ── Barra di navigazione fissa in fondo ─────────── */}
      <div style={{
        flexShrink:0,padding:'14px 36px',borderTop:'1px solid var(--vp-paper-3)',
        background:'var(--vp-paper)',display:'flex',alignItems:'center',justifyContent:'space-between',gap:16,
      }}>
        <button className="vp-btn vp-btn--ghost" disabled={step===1}
          onClick={()=>setStep(s=>Math.max(1,s-1))}
          style={{opacity:step===1?.4:1,pointerEvents:step===1?'none':'auto'}}>
          <VPIcon name="back" size={16}/> Indietro
        </button>
        <div style={{fontSize:13,color:'var(--vp-ink-3)'}}>
          {incompleto
            ? `Mancano ${mancanti} bollette per chiudere ${per.label}`
            : step===1 ? '3 bollette lette · totale ' + eur(CG_TOT)
            : step===2 ? 'Somma quote ' + eur(sommaQuote) + ' — torna il conto'
            : CG_INQ.length + ' avvisi pronti all\u2019invio'}
        </div>
        {incompleto ? (
          <button className="vp-btn vp-btn--primary"><VPIcon name="upload" size={16} color="#fff"/> Carica le {mancanti} mancanti</button>
        ) : step<LAST ? (
          <button className="vp-btn vp-btn--primary" onClick={()=>setStep(s=>Math.min(LAST,s+1))}>
            {['Vai alla ripartizione','Prepara gli avvisi'][step-1]} <VPIcon name="arrow" size={16} color="#fff"/>
          </button>
        ) : (
          <button className="vp-btn vp-btn--primary">
            <VPEnvelope size={16} color="#fff"/> Invia {CG_INQ.length} avvisi
          </button>
        )}
      </div>
    </div>
  );
}

// Badge di stato periodo
function CGStatoBadge({ per, compact }) {
  if (per.stato==='inviato')   return <span className="vp-badge vp-badge--ok"><VPIcon name="check" size={12} stroke={2.6}/>{compact?'':' inviato'}</span>;
  if (per.stato==='da-inviare')return <span className="vp-badge vp-badge--wait">{compact?'da inviare':'da inviare'}</span>;
  return <span className="vp-badge vp-badge--late"><VPIcon name="alert" size={12}/> {per.attese-per.presenti} mancanti</span>;
}

// Stato bloccato quando mancano bollette
function CGBloccato({ mancanti }) {
  return (
    <div style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',textAlign:'center',padding:'56px 24px',gap:14}}>
      <div style={{width:64,height:64,borderRadius:18,background:'var(--vp-clay-soft)',display:'flex',alignItems:'center',justifyContent:'center'}}>
        <VPIcon name="lock" size={28} color="var(--vp-clay)"/>
      </div>
      <div className="vp-display" style={{fontSize:22}}>Prima completa le bollette</div>
      <div style={{fontSize:14,color:'var(--vp-ink-2)',maxWidth:420}}>Mancano <b>{mancanti} bollette</b> di questo periodo. La ripartizione e l’invio si sbloccano quando il totale è completo.</div>
      <button className="vp-btn vp-btn--primary" style={{marginTop:4}}><VPIcon name="upload" size={16} color="#fff"/> Torna a “Bolletta”</button>
    </div>
  );
}

// ── Grafica scontrino (ricevuta cartacea) ─────────────────────
function Scontrino({ bill, tilt = 0, w = 150, read = true, mini = false }) {
  const c = CG_COLORS[bill.tipo];
  const teeth = mini ? 7 : 14;
  return (
    <div style={{
      width:w, background:'#f6efe2', borderRadius:'4px 4px 0 0',
      transform:`rotate(${tilt}deg)`, boxShadow:'var(--vp-shadow-2)',
      fontFamily:'var(--vp-font-mono)', color:'#3a2f24', position:'relative',
      paddingBottom:mini?6:10,
    }}>
      <div style={{padding:mini?'9px 9px 7px':'13px 14px 10px'}}>
        <div style={{display:'flex',alignItems:'center',gap:5,marginBottom:mini?5:7}}>
          <VPIcon name={bill.icon} size={mini?11:13} color={c.fg}/>
          <span style={{fontWeight:700,fontSize:mini?9:11,letterSpacing:'0.04em'}}>{bill.tipo.toUpperCase()}</span>
        </div>
        {!mini && (
          <div style={{fontSize:9,lineHeight:1.7,color:'#6b5d4a'}}>
            <div style={{fontWeight:700,color:'#3a2f24'}}>{bill.fornitore}</div>
            <div>Periodo {bill.periodo}</div>
            <div>Consumo {bill.consumo}</div>
            <div>{bill.rif}</div>
          </div>
        )}
        <div style={{borderTop:'1.5px dashed #c5b48f',margin:mini?'6px 0 5px':'9px 0 8px'}}/>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'baseline'}}>
          {!mini && <span style={{fontSize:9,color:'#6b5d4a'}}>TOTALE</span>}
          <span style={{fontWeight:700,fontSize:mini?11:15,color:c.fg}}>{eur(bill.importo)}</span>
        </div>
        {read && !mini && (
          <div style={{display:'flex',alignItems:'center',gap:4,marginTop:8,fontSize:8.5,color:'var(--vp-sage-deep)',fontFamily:'var(--vp-font-ui)'}}>
            <VPIcon name="check" size={11} stroke={2.6} color="var(--vp-sage)"/> letto dall’AI
          </div>
        )}
      </div>
      {/* bordo dentellato in basso */}
      <svg width={w} height={mini?6:8} viewBox={`0 0 ${teeth*10} 8`} preserveAspectRatio="none" style={{display:'block'}}>
        <polygon points={Array.from({length:teeth}).map((_,i)=>`${i*10},0 ${i*10+5},8 ${i*10+10},0`).join(' ')} fill="#f6efe2"/>
      </svg>
    </div>
  );
}

// ── Vista 1 · BOLLETTA — upload compatto + dettaglio + composizione ──
function CGBolletta({ per, incompleto, mancanti }) {
  const nPres = per ? per.presenti : CG_BILLS.length;
  const present = CG_BILLS.slice(0, nPres);
  const missing = CG_BILLS.slice(nPres);
  const totPres = present.reduce((s,b)=>s+b.importo,0);
  return (
    <div>
      {/* Striscia upload compatta (multipla) con mini-scontrini */}
      <div style={{display:'flex',alignItems:'center',gap:16,padding:'12px 16px 12px 12px',marginBottom:18,
        border:`1.5px dashed ${incompleto?'var(--vp-clay)':'var(--vp-terra)'}`,borderRadius:14,
        background:incompleto?'var(--vp-clay-soft)':'var(--vp-terra-soft)'}}>
        <div style={{display:'flex',alignItems:'flex-start',flexShrink:0}}>
          {present.map((b,i)=>(
            <div key={i} style={{marginLeft:i?-16:0,marginTop:i*3,zIndex:i}}><Scontrino bill={b} tilt={-6+i*7} w={52} mini/></div>
          ))}
        </div>
        <div style={{flex:1}}>
          <div style={{fontSize:15,fontWeight:600,color:incompleto?'oklch(0.40 0.11 28)':'var(--vp-terra-deep)'}}>
            {incompleto ? `${nPres} di ${per.attese} bollette · mancano ${missing.map(m=>m.tipo).join(' e ')}` : '3 bollette lette · Enel, ENI, Comune'}
          </div>
          <div style={{fontSize:13,color:'var(--vp-ink-2)',marginTop:2}}>Importo e periodo riconosciuti dall’AI. Trascina altri PDF per aggiungerne — l’upload è multiplo.</div>
        </div>
        <button className="vp-btn vp-btn--ghost" style={{flexShrink:0}}><VPIcon name="upload" size={15}/> Aggiungi</button>
      </div>

      <div style={{display:'flex',justifyContent:'space-between',alignItems:'baseline',marginBottom:14}}>
        <div className="vp-display" style={{fontSize:21}}>Dettaglio delle utenze</div>
        <div style={{fontSize:13,color:'var(--vp-ink-3)'}}>importo, periodo e consumo di ogni bolletta</div>
      </div>

      {/* Ricevute presenti + slot mancanti */}
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:16,marginBottom:18}}>
        {present.map((b,i)=>{
          const c = CG_COLORS[b.tipo];
          return (
            <div key={i} className="vp-card" style={{padding:0,overflow:'hidden',display:'flex',flexDirection:'column'}}>
              <div style={{display:'flex',alignItems:'center',gap:10,padding:'14px 18px',background:c.soft,color:c.fg}}>
                <div style={{width:34,height:34,borderRadius:9,background:'var(--vp-cream)',display:'flex',alignItems:'center',justifyContent:'center'}}>
                  <VPIcon name={b.icon} size={18} color={c.fg}/>
                </div>
                <div>
                  <div style={{fontSize:16,fontWeight:600}}>{b.tipo}</div>
                  <div style={{fontSize:12,opacity:.8}}>{b.fornitore}</div>
                </div>
              </div>
              <div style={{padding:'16px 18px',flex:1,display:'flex',flexDirection:'column',gap:9}}>
                <CGBillRow label="Periodo" value={b.periodo}/>
                <CGBillRow label="Consumo" value={b.consumo}/>
                <CGBillRow label="Riferimento" value={b.rif} mono/>
                <div style={{borderTop:'1px dashed var(--vp-paper-3)',margin:'4px 0'}}/>
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'baseline'}}>
                  <span style={{fontSize:13,color:'var(--vp-ink-3)'}}>Importo</span>
                  <span className="vp-mono" style={{fontSize:22,fontFamily:'var(--vp-font-display)',color:c.fg}}>{eur(b.importo)}</span>
                </div>
              </div>
              <div style={{display:'flex',alignItems:'center',gap:6,padding:'10px 18px',borderTop:'1px solid var(--vp-paper-3)',fontSize:12,color:'var(--vp-sage-deep)'}}>
                <VPIcon name="check" size={13} stroke={2.4} color="var(--vp-sage)"/> PDF letto correttamente
              </div>
            </div>
          );
        })}
        {missing.map((b,i)=>{
          const c = CG_COLORS[b.tipo];
          return (
            <button key={'m'+i} style={{
              border:'1.5px dashed var(--vp-paper-3)',borderRadius:'var(--vp-r-card,16px)',background:'var(--vp-paper-2)',
              display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:10,padding:'24px',
              cursor:'pointer',fontFamily:'inherit',color:'var(--vp-ink-3)',minHeight:200,
            }}>
              <div style={{width:40,height:40,borderRadius:11,background:c.soft,display:'flex',alignItems:'center',justifyContent:'center'}}>
                <VPIcon name={b.icon} size={20} color={c.fg}/>
              </div>
              <div style={{fontSize:15,fontWeight:600,color:'var(--vp-ink-2)'}}>{b.tipo} mancante</div>
              <div style={{display:'flex',alignItems:'center',gap:6,fontSize:13,color:'var(--vp-terra-deep)',fontWeight:500}}>
                <VPIcon name="upload" size={14} color="var(--vp-terra-deep)"/> Carica la bolletta
              </div>
            </button>
          );
        })}
      </div>

      {/* Di cosa si compone / avviso incompleto */}
      {incompleto ? (
        <div className="vp-banner vp-banner--late">
          <VPIcon name="alert" size={18} color="var(--vp-clay)" style={{marginTop:2}}/>
          <div style={{flex:1}}>
            <b>Totale non ancora completo.</b>{' '}
            <span style={{color:'var(--vp-ink-2)'}}>Finora {eur(totPres)} su {nPres} di {per.attese} bollette. Carica le {mancanti} mancanti per sbloccare ripartizione e invio.</span>
          </div>
        </div>
      ) : (
      <div className="vp-card" style={{padding:'22px 26px'}}>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'baseline',marginBottom:18}}>
          <div className="vp-display" style={{fontSize:20}}>Di cosa si compone</div>
          <div style={{fontSize:13,color:'var(--vp-ink-3)'}}>Somma delle tre utenze del periodo</div>
        </div>

        {/* Barra segmentata */}
        <div style={{display:'flex',height:18,borderRadius:'var(--vp-r-pill)',overflow:'hidden',marginBottom:18}}>
          {CG_BILLS.map((b,i)=>(
            <div key={i} title={b.tipo} style={{width:`${b.importo/CG_TOT*100}%`,background:CG_COLORS[b.tipo].bar}}/>
          ))}
        </div>

        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr auto',gap:20,alignItems:'center'}}>
          {CG_BILLS.map((b,i)=>{
            const c = CG_COLORS[b.tipo];
            return (
              <div key={i} style={{display:'flex',alignItems:'center',gap:11}}>
                <span style={{width:12,height:12,borderRadius:4,background:c.bar,flexShrink:0}}/>
                <div>
                  <div style={{fontSize:13,color:'var(--vp-ink-2)'}}>{b.tipo} <span style={{color:'var(--vp-ink-4)'}}>· {Math.round(b.importo/CG_TOT*100)}%</span></div>
                  <div className="vp-mono" style={{fontSize:18,fontWeight:500}}>{eur(b.importo)}</div>
                </div>
              </div>
            );
          })}
          <div style={{textAlign:'right',paddingLeft:18,borderLeft:'1px solid var(--vp-paper-3)'}}>
            <div className="vp-eyebrow">Totale periodo</div>
            <div className="vp-mono" style={{fontSize:30,fontFamily:'var(--vp-font-display)',marginTop:2}}>{eur(CG_TOT)}</div>
          </div>
        </div>
      </div>
      )}
    </div>
  );
}

function CGBillRow({ label, value, mono }) {
  return (
    <div style={{display:'flex',justifyContent:'space-between',alignItems:'baseline',fontSize:13}}>
      <span style={{color:'var(--vp-ink-3)'}}>{label}</span>
      <span className={mono?'vp-mono':''} style={{color:'var(--vp-ink)',fontWeight:mono?400:500,fontSize:mono?12:13}}>{value}</span>
    </div>
  );
}

// ── Vista 2 · RIPARTIZIONE — criterio + tabella per utenza ────
function CGRipartizione({ criterio, setCriterio, quote, sommaQuote }) {
  return (
    <div>
      {/* Criterio */}
      <div className="vp-card" style={{padding:'22px 24px',marginBottom:16}}>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'baseline',marginBottom:14}}>
          <div className="vp-display" style={{fontSize:20}}>Come dividiamo le tre utenze?</div>
          <div style={{fontSize:13,color:'var(--vp-ink-3)'}}>Cambia il criterio, le quote si aggiornano subito.</div>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:10}}>
          {[
            ['teste','A testa','Stessa quota per tutti','users'],
            ['mq','Per stanza','In base ai m² della camera','home'],
            ['giorni','Pro-rata giorni','Solo i giorni di presenza','clock'],
          ].map(([k,t,sub,ic]) => (
            <button key={k} onClick={()=>setCriterio(k)} style={{
              padding:'14px 16px',borderRadius:12,cursor:'pointer',textAlign:'left',
              background:criterio===k?'var(--vp-terra-soft)':'var(--vp-paper-2)',
              border:`1.5px solid ${criterio===k?'var(--vp-terra)':'transparent'}`,
              color:criterio===k?'var(--vp-terra-deep)':'var(--vp-ink)',fontFamily:'inherit',
            }}>
              <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:4}}>
                <VPIcon name={ic} size={16}/>
                <span style={{fontSize:14,fontWeight:500}}>{t}</span>
              </div>
              <div style={{fontSize:12,color:criterio===k?'var(--vp-terra-deep)':'var(--vp-ink-3)'}}>{sub}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Tabella per-utenza */}
      <div className="vp-card" style={{overflow:'hidden',marginBottom:16}}>
        <div style={{padding:'16px 22px',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
          <div className="vp-display" style={{fontSize:20}}>Quota per inquilino</div>
          <span style={{fontSize:13,color:'var(--vp-ink-3)'}}>Dettaglio Luce · Gas · TARI per persona</span>
        </div>
        <table className="vp-table">
          <thead>
            <tr>
              <th>Inquilino</th>
              <th style={{textAlign:'right'}}>{criterio==='mq'?'m²':'Giorni'}</th>
              <th style={{textAlign:'right',color:CG_COLORS.Luce.fg}}>Luce</th>
              <th style={{textAlign:'right',color:CG_COLORS.Gas.fg}}>Gas</th>
              <th style={{textAlign:'right',color:CG_COLORS.TARI.fg}}>TARI</th>
              <th style={{textAlign:'right'}}>Quota</th>
            </tr>
          </thead>
          <tbody>
            {quote.map((q,i)=>(
              <tr key={i}>
                <td>
                  <div style={{display:'flex',alignItems:'center',gap:10}}>
                    <VPAvatar name={q.nome} size={30} hue={q.hue}/>
                    <div>
                      <div style={{fontWeight:500}}>{q.nome}</div>
                      <div style={{fontSize:12,color:'var(--vp-ink-3)'}}>{q.stanza}</div>
                    </div>
                  </div>
                </td>
                <td style={{textAlign:'right'}} className="vp-mono">{criterio==='mq'?q.mq:q.giorni}</td>
                <td style={{textAlign:'right'}} className="vp-mono">{eur(q.per.Luce)}</td>
                <td style={{textAlign:'right'}} className="vp-mono">{eur(q.per.Gas)}</td>
                <td style={{textAlign:'right'}} className="vp-mono">{eur(q.per.TARI)}</td>
                <td style={{textAlign:'right'}} className="vp-mono">
                  <span style={{fontWeight:600,fontSize:15}}>{eur(q.quota)}</span>
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr>
              <td style={{fontWeight:600}}>Totale</td>
              <td/>
              <td style={{textAlign:'right'}} className="vp-mono" >{eur(CG_BILLS[0].importo)}</td>
              <td style={{textAlign:'right'}} className="vp-mono">{eur(CG_BILLS[1].importo)}</td>
              <td style={{textAlign:'right'}} className="vp-mono">{eur(CG_BILLS[2].importo)}</td>
              <td style={{textAlign:'right'}} className="vp-mono"><b>{eur(sommaQuote)}</b></td>
            </tr>
          </tfoot>
        </table>
      </div>

      {criterio==='giorni' && (
        <div className="vp-banner">
          <VPLeaf size={20}/>
          <div style={{flex:1}}>
            <b>Anna è entrata il 14 marzo.</b>{' '}
            <span style={{color:'var(--vp-ink-2)'}}>Con il criterio “pro-rata giorni” paga solo i 18 giorni di effettiva presenza: la sua quota scende e si redistribuisce sugli altri.</span>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Vista 3 · INVIO — anteprime messaggio + riepilogo ─────────
function CGInvio({ quote, criterio, openMsg, setOpenMsg, per }) {
  const critLabel = { teste:'a testa', mq:'per m² di stanza', giorni:'sui giorni di effettiva presenza' }[criterio];
  const periodoTxt = per ? `${per.label}` : 'Marzo 2026';
  return (
    <div style={{display:'grid',gridTemplateColumns:'1fr 340px',gap:22,alignItems:'start'}}>
      {/* Lista destinatari */}
      <div className="vp-card" style={{overflow:'hidden'}}>
        <div style={{padding:'16px 22px',display:'flex',justifyContent:'space-between',alignItems:'center',borderBottom:'1px solid var(--vp-paper-3)'}}>
          <div className="vp-display" style={{fontSize:20}}>Avvisi agli inquilini</div>
          <span className="vp-badge vp-badge--wait"><VPIcon name="message" size={13}/> anteprima</span>
        </div>
        {quote.map((q,i)=>{
          const open = openMsg===i;
          return (
            <div key={i} style={{borderBottom:i<quote.length-1?'1px solid var(--vp-paper-3)':'none'}}>
              <button onClick={()=>setOpenMsg(open?-1:i)} style={{
                width:'100%',display:'flex',alignItems:'center',gap:12,padding:'14px 22px',
                background:open?'var(--vp-paper-2)':'transparent',border:'none',cursor:'pointer',
                textAlign:'left',fontFamily:'inherit',color:'var(--vp-ink)',
              }}>
                <VPAvatar name={q.nome} size={36} hue={q.hue}/>
                <div style={{flex:1}}>
                  <div style={{fontWeight:500,fontSize:15}}>{q.nome}</div>
                  <div style={{fontSize:12,color:'var(--vp-ink-3)'}}>{q.email}</div>
                </div>
                <span className="vp-mono" style={{fontSize:15,fontWeight:600}}>{eur(q.quota)}</span>
                <VPIcon name="chevron" size={16} color="var(--vp-ink-3)" style={{transform:open?'rotate(90deg)':'none',transition:'transform .15s'}}/>
              </button>
              {open && (
                <div style={{padding:'4px 22px 22px 70px'}}>
                  <div style={{background:'var(--vp-paper-2)',borderRadius:12,padding:'18px 20px',fontSize:13,color:'var(--vp-ink-2)',lineHeight:1.6}}>
                    <div style={{fontWeight:600,color:'var(--vp-ink)',marginBottom:8,fontSize:14}}>Viapal — conguaglio utenze · {periodoTxt}</div>
                    <div>Ciao {q.nome},</div>
                    <div style={{marginTop:8}}>è disponibile il conteggio delle utenze per {periodoTxt} (periodo {per?per.range:'01/03 – 31/03'}).</div>
                    <div style={{marginTop:4}}>Il tuo importo è di <b style={{color:'var(--vp-ink)'}}>{eur(q.quota)}</b> (luce, gas e TARI ripartiti {critLabel}).</div>
                    <div style={{marginTop:10}}>Dettaglio:</div>
                    <ul style={{margin:'4px 0 0',paddingLeft:18}}>
                      <li>Luce: {eur(q.per.Luce)}</li>
                      <li>Gas: {eur(q.per.Gas)}</li>
                      <li>TARI: {eur(q.per.TARI)}</li>
                      <li>Giorni di presenza nel periodo: {q.giorni}</li>
                    </ul>
                    <div style={{marginTop:10}}>Vedi il dettaglio nell’app Viapal.</div>
                    <div style={{marginTop:10}}>Grazie,<br/>i proprietari</div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Riepilogo invio */}
      <aside style={{position:'sticky',top:0,display:'flex',flexDirection:'column',gap:14}}>
        <div className="vp-card" style={{padding:'22px 24px'}}>
          <div className="vp-eyebrow">Riepilogo invio</div>
          <div className="vp-display" style={{fontSize:34,marginTop:6}}>{quote.length} avvisi</div>
          <div style={{fontSize:13,color:'var(--vp-ink-3)',marginBottom:18}}>pronti per marzo 2026</div>

          <div style={{display:'flex',flexDirection:'column',gap:9,marginBottom:18}}>
            <div style={{display:'flex',justifyContent:'space-between',fontSize:14}}>
              <span style={{color:'var(--vp-ink-2)'}}>Totale conguagliato</span>
              <span className="vp-mono" style={{fontWeight:600}}>{eur(quote.reduce((s,q)=>s+q.quota,0))}</span>
            </div>
            <div style={{display:'flex',justifyContent:'space-between',fontSize:14}}>
              <span style={{color:'var(--vp-ink-2)'}}>Quota media</span>
              <span className="vp-mono">{eur(quote.reduce((s,q)=>s+q.quota,0)/quote.length)}</span>
            </div>
            <div style={{display:'flex',justifyContent:'space-between',fontSize:14}}>
              <span style={{color:'var(--vp-ink-2)'}}>Canale</span>
              <span style={{fontWeight:500}}>Email + push</span>
            </div>
          </div>

          <button className="vp-btn vp-btn--primary" style={{width:'100%'}}>
            <VPEnvelope size={16} color="#fff"/> Invia {quote.length} avvisi
          </button>
          <button className="vp-btn vp-btn--ghost" style={{width:'100%',marginTop:8}}>Salva in bozza</button>
        </div>

        <div className="vp-banner vp-banner--ok" style={{fontSize:13}}>
          <VPIcon name="check" size={18} stroke={2.4} color="var(--vp-sage-deep)"/>
          <div>Gli inquilini ricevono l’importo e il <b>dettaglio per utenza</b>. La quota diventa un addebito in app.</div>
        </div>
      </aside>
    </div>
  );
}

function Stat({ label, value, big }) {
  return (
    <div>
      <div className="vp-eyebrow">{label}</div>
      <div className="vp-mono" style={{fontSize:big?22:15,fontWeight:big?500:400,marginTop:2,fontFamily:big?'var(--vp-font-display)':'var(--vp-font-ui)'}}>{value}</div>
    </div>
  );
}

window.ProtoConguaglio = ProtoConguaglio;


// ── Prototipo 5: Conti tra fratelli (desktop) ────────────────
function ProtoFratelli() {
  const fratelli = [
    { nome: 'Elena',  quota: 40, hue: 30 },
    { nome: 'Giulio', quota: 35, hue: 90 },
    { nome: 'Laura',  quota: 25, hue: 145 },
  ];
  const utiliAnno = 22450;

  const movimenti = [
    { who: 'Giulio', what: 'Idraulico (rubinetto cucina)', amount: 180, date: '12 set', tag: 'Manutenzione' },
    { who: 'Elena',  what: 'Assicurazione casa', amount: 340, date: '5 set', tag: 'Assicurazione' },
    { who: 'Laura',  what: 'IMU acconto', amount: 1200, date: '16 giu', tag: 'Tasse' },
    { who: 'Elena',  what: 'Bolletta condominio Q3', amount: 220, date: '28 ago', tag: 'Condominio' },
    { who: 'Giulio', what: 'Imbianchino corridoio', amount: 480, date: '4 lug', tag: 'Manutenzione' },
  ];

  // Saldi reciproci semplificati
  const saldi = [
    { from: 'Giulio', to: 'Elena',  amount: 124 },
    { from: 'Laura',  to: 'Elena',  amount: 86 },
  ];

  return (
    <div style={{width:'100%',height:'100%',overflow:'auto',background:'var(--vp-paper)',color:'var(--vp-ink)',fontFamily:'var(--vp-font-ui)'}} className="vp-scroll">
      <div style={{padding:'28px 40px 56px',maxWidth:1200,margin:'0 auto'}}>
        <div className="vp-eyebrow" style={{marginBottom:6}}>Conti tra fratelli · 2026</div>
        <h1 className="vp-display" style={{fontSize:36,margin:'0 0 6px'}}>Tutto torna, fratelli.</h1>
        <div style={{color:'var(--vp-ink-2)',fontSize:15,marginBottom:30}}>
          A oggi <b>4 ottobre</b>, ci sono <b>2 piccoli giroconti</b> da fare. Niente di che.
        </div>

        {/* Colonna 1+2 */}
        <div style={{display:'grid',gridTemplateColumns:'1.4fr 1fr',gap:22,marginBottom:22}}>
          {/* Quote di proprietà + utili */}
          <div className="vp-card" style={{padding:'24px 28px',position:'relative',overflow:'hidden'}}>
            <div className="vp-eyebrow">Utili 2026 da distribuire</div>
            <div className="vp-display" style={{fontSize:48,marginTop:6}}>€ {utiliAnno.toLocaleString('it-IT')}</div>
            <div style={{color:'var(--vp-ink-2)',fontSize:14,marginBottom:24}}>Affitti incassati − spese, dopo IMU.</div>

            {/* Barra orizzontale segmentata */}
            <div style={{display:'flex',height:14,borderRadius:'var(--vp-r-pill)',overflow:'hidden',marginBottom:18}}>
              {fratelli.map((f,i) => (
                <div key={i} style={{
                  width:`${f.quota}%`,
                  background:`oklch(0.68 0.08 ${f.hue})`,
                }}/>
              ))}
            </div>
            <div style={{display:'flex',justifyContent:'space-between',gap:20}}>
              {fratelli.map((f,i) => (
                <div key={i} style={{flex:1}}>
                  <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:6}}>
                    <VPAvatar name={f.nome} size={32} hue={f.hue}/>
                    <div>
                      <div style={{fontSize:14,fontWeight:500}}>{f.nome}</div>
                      <div style={{fontSize:12,color:'var(--vp-ink-3)'}}>{f.quota}% di proprietà</div>
                    </div>
                  </div>
                  <div className="vp-mono" style={{fontSize:20,marginTop:8,fontFamily:'var(--vp-font-display)'}}>€ {Math.round(utiliAnno*f.quota/100).toLocaleString('it-IT')}</div>
                </div>
              ))}
            </div>
            <div style={{position:'absolute',right:-30,bottom:-30,opacity:0.06}}><VPHouse size={180}/></div>
          </div>

          {/* Saldi reciproci */}
          <div className="vp-card" style={{padding:'24px 28px'}}>
            <div className="vp-eyebrow">Giroconti consigliati</div>
            <div className="vp-display" style={{fontSize:22,marginTop:6,marginBottom:18}}>Chi deve cosa, oggi</div>

            <div style={{display:'flex',flexDirection:'column',gap:14}}>
              {saldi.map((s,i) => {
                const fromHue = fratelli.find(f=>f.nome===s.from).hue;
                const toHue = fratelli.find(f=>f.nome===s.to).hue;
                return (
                  <div key={i} style={{
                    display:'flex',alignItems:'center',gap:12,
                    padding:'14px 16px',borderRadius:14,
                    background:'var(--vp-paper-2)',
                  }}>
                    <VPAvatar name={s.from} size={36} hue={fromHue}/>
                    <div style={{flex:1,display:'flex',alignItems:'center',gap:10}}>
                      <span style={{fontSize:14,fontWeight:500}}>{s.from}</span>
                      <VPIcon name="arrow" size={16} color="var(--vp-ink-3)"/>
                      <span style={{fontSize:14,fontWeight:500}}>{s.to}</span>
                    </div>
                    <VPAvatar name={s.to} size={36} hue={toHue}/>
                    <div className="vp-mono" style={{fontSize:18,fontFamily:'var(--vp-font-display)'}}>€ {s.amount}</div>
                  </div>
                );
              })}
            </div>
            <button className="vp-btn vp-btn--primary" style={{width:'100%',marginTop:18}}>
              Segna come saldato
            </button>
            <div style={{marginTop:14,fontSize:13,color:'var(--vp-ink-3)',textAlign:'center'}}>
              Ultimo conguaglio: <b style={{color:'var(--vp-ink-2)'}}>30 giugno '26</b>
            </div>
          </div>
        </div>

        {/* Movimenti recenti */}
        <div className="vp-card" style={{overflow:'hidden'}}>
          <div style={{padding:'18px 22px',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
            <div>
              <div className="vp-display" style={{fontSize:20}}>Spese anticipate dai fratelli</div>
              <div style={{fontSize:13,color:'var(--vp-ink-3)',marginTop:2}}>Verranno scalate dagli utili o saldate a fine anno.</div>
            </div>
            <button className="vp-btn vp-btn--ghost"><VPIcon name="plus" size={14}/>Aggiungi</button>
          </div>
          <table className="vp-table">
            <thead>
              <tr>
                <th>Anticipato da</th>
                <th>Spesa</th>
                <th>Categoria</th>
                <th>Data</th>
                <th style={{textAlign:'right'}}>Importo</th>
              </tr>
            </thead>
            <tbody>
              {movimenti.map((m,i)=>{
                const hue = fratelli.find(f=>f.nome===m.who)?.hue || 30;
                return (
                  <tr key={i}>
                    <td>
                      <div style={{display:'flex',alignItems:'center',gap:10}}>
                        <VPAvatar name={m.who} size={28} hue={hue}/>
                        <span style={{fontWeight:500}}>{m.who}</span>
                      </div>
                    </td>
                    <td>{m.what}</td>
                    <td><span className="vp-badge vp-badge--neutral">{m.tag}</span></td>
                    <td style={{color:'var(--vp-ink-3)'}}>{m.date}</td>
                    <td style={{textAlign:'right'}} className="vp-mono">€ {m.amount.toLocaleString('it-IT')}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

window.ProtoFratelli = ProtoFratelli;
