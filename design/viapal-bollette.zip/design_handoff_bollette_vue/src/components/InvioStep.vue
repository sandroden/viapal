<script setup>
// STEP 3 · INVIO
// Expandable per-tenant message previews (left) + send summary (right).
import { ref, computed } from 'vue';
import VpIcon from './VpIcon.vue';
import VpAvatar from './VpAvatar.vue';
import { eur, criterioFrase } from '../lib/format.js';

const props = defineProps({
  periodo:  { type: Object, required: true },  // { label, range }
  quote:    { type: Array, required: true },    // QuotaInquilino[]
  criterio: { type: String, required: true },
});
const emit = defineEmits(['invia', 'salva-bozza']);

const openIdx = ref(0); // first preview open by default
const critFrase = computed(() => criterioFrase(props.criterio));
const totale = computed(() => props.quote.reduce((s, q) => s + q.quota, 0));
const media  = computed(() => (props.quote.length ? totale.value / props.quote.length : 0));
function toggle(i) { openIdx.value = openIdx.value === i ? -1 : i; }
</script>

<template>
  <div class="layout">
    <!-- Destinatari -->
    <div class="vp-card list">
      <div class="list-head">
        <div class="vp-display" style="font-size:20px">Avvisi agli inquilini</div>
        <span class="vp-badge vp-badge--wait"><VpIcon name="message" :size="13" /> anteprima</span>
      </div>

      <div v-for="(q, i) in quote" :key="q.id ?? q.nome" class="rowwrap" :class="{ last: i === quote.length - 1 }">
        <button class="row" :class="{ open: openIdx === i }" @click="toggle(i)">
          <VpAvatar :name="q.nome" :size="36" :hue="q.avatarHue" />
          <div class="row-main">
            <div class="row-name">{{ q.nome }}</div>
            <div class="row-mail">{{ q.email }}</div>
          </div>
          <span class="vp-mono row-quota">{{ eur(q.quota) }}</span>
          <VpIcon name="chevron" :size="16" color="var(--vp-ink-3)" :style="{ transform: openIdx === i ? 'rotate(90deg)' : 'none', transition: 'transform .15s' }" />
        </button>

        <div v-if="openIdx === i" class="msg-wrap">
          <div class="msg">
            <div class="msg-subj">Viapal — conguaglio utenze · {{ periodo.label }}</div>
            <div>Ciao {{ q.nome }},</div>
            <div style="margin-top:8px">è disponibile il conteggio delle utenze per {{ periodo.label }} (periodo {{ periodo.range }}).</div>
            <div style="margin-top:4px">Il tuo importo è di <b class="ink">{{ eur(q.quota) }}</b> (luce, gas e TARI ripartiti {{ critFrase }}).</div>
            <div style="margin-top:10px">Dettaglio:</div>
            <ul class="msg-ul">
              <li>Luce: {{ eur(q.per.Luce) }}</li>
              <li>Gas: {{ eur(q.per.Gas) }}</li>
              <li>TARI: {{ eur(q.per.TARI) }}</li>
              <li>Giorni di presenza nel periodo: {{ q.giorni }}</li>
            </ul>
            <div style="margin-top:10px">Vedi il dettaglio nell’app Viapal.</div>
            <div style="margin-top:10px">Grazie,<br />i proprietari</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Riepilogo -->
    <aside class="aside">
      <div class="vp-card summary">
        <div class="vp-eyebrow">Riepilogo invio</div>
        <div class="vp-display sum-n">{{ quote.length }} avvisi</div>
        <div class="muted" style="margin-bottom:18px">pronti per {{ periodo.label }}</div>

        <div class="kvs">
          <div class="kv"><span>Totale conguagliato</span><span class="vp-mono b">{{ eur(totale) }}</span></div>
          <div class="kv"><span>Quota media</span><span class="vp-mono">{{ eur(media) }}</span></div>
          <div class="kv"><span>Canale</span><span class="b">Email + push</span></div>
        </div>

        <button class="vp-btn vp-btn--primary full" @click="emit('invia')"><VpIcon name="message" :size="16" color="#fff" /> Invia {{ quote.length }} avvisi</button>
        <button class="vp-btn vp-btn--ghost full" style="margin-top:8px" @click="emit('salva-bozza')">Salva in bozza</button>
      </div>

      <div class="vp-banner vp-banner--ok" style="font-size:13px">
        <VpIcon name="check" :size="18" :stroke="2.4" color="var(--vp-sage-deep)" />
        <div>Gli inquilini ricevono l’importo e il <b>dettaglio per utenza</b>. La quota diventa un addebito in app.</div>
      </div>
    </aside>
  </div>
</template>

<style scoped>
.muted { font-size: 13px; color: var(--vp-ink-3); }
.ink { color: var(--vp-ink); }
.layout { display: grid; grid-template-columns: 1fr 340px; gap: 22px; align-items: start; }

.list { overflow: hidden; }
.list-head { padding: 16px 22px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--vp-paper-3); }
.rowwrap { border-bottom: 1px solid var(--vp-paper-3); }
.rowwrap.last { border-bottom: none; }
.row {
  width: 100%; display: flex; align-items: center; gap: 12px; padding: 14px 22px;
  background: transparent; border: none; cursor: pointer; text-align: left; font-family: inherit; color: var(--vp-ink);
}
.row.open { background: var(--vp-paper-2); }
.row-main { flex: 1; }
.row-name { font-weight: 500; font-size: 15px; }
.row-mail { font-size: 12px; color: var(--vp-ink-3); }
.row-quota { font-size: 15px; font-weight: 600; }
.msg-wrap { padding: 4px 22px 22px 70px; }
.msg { background: var(--vp-paper-2); border-radius: 12px; padding: 18px 20px; font-size: 13px; color: var(--vp-ink-2); line-height: 1.6; }
.msg-subj { font-weight: 600; color: var(--vp-ink); margin-bottom: 8px; font-size: 14px; }
.msg-ul { margin: 4px 0 0; padding-left: 18px; }

.aside { position: sticky; top: 0; display: flex; flex-direction: column; gap: 14px; }
.summary { padding: 22px 24px; }
.sum-n { font-size: 34px; margin-top: 6px; }
.kvs { display: flex; flex-direction: column; gap: 9px; margin-bottom: 18px; }
.kv { display: flex; justify-content: space-between; font-size: 14px; }
.kv > span:first-child { color: var(--vp-ink-2); }
.kv .b, .b { font-weight: 600; }
.full { width: 100%; }
</style>
