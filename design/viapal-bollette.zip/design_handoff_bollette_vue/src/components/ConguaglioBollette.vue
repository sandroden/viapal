<script setup>
/*
  ConguaglioBollette — wizard container for the "bollette" feature.

  This is a PRESENTATIONAL shell. All numbers (bills, totals, quote splits,
  period list/status) come in as props from your existing store. The shell
  owns only UI-local state: which step is shown, and which message preview
  is expanded (inside InvioStep).

  v-model:
    periodoId  (String)  — selected period id
    criterio   (String)  — 'teste' | 'mq' | 'giorni'

  Events:
    upload     — user asked to add/upload bills (optionally a utility type)
    invia      — user clicked "Invia avvisi"
    salva-bozza

  Expected prop shapes — see README §"Data contract".
*/
import { ref, computed, watch } from 'vue';
import VpIcon from './VpIcon.vue';
import PeriodSelector from './PeriodSelector.vue';
import BollettaStep from './BollettaStep.vue';
import RipartizioneStep from './RipartizioneStep.vue';
import InvioStep from './InvioStep.vue';
import BloccatoState from './BloccatoState.vue';
import { eur } from '../lib/format.js';

const props = defineProps({
  periodi:      { type: Array, required: true },   // Periodo[]
  periodoId:    { type: String, required: true },  // v-model
  criterio:     { type: String, required: true },  // v-model
  bollette:     { type: Array, required: true },   // present Bolletta[] for the selected period
  totale:       { type: Number, required: true },  // sum of present bills
  quote:        { type: Array, required: true },   // QuotaInquilino[]
  totaliUtenza: { type: Object, required: true },  // { Luce, Gas, TARI }
  pagataDa:     { type: String, default: '' },
  nInquilini:   { type: Number, default: 0 },
  hasNuovoIngresso: { type: Boolean, default: false },
  ingressoNota:     { type: String, default: '' },
});
const emit = defineEmits(['update:periodoId', 'update:criterio', 'upload', 'invia', 'salva-bozza']);

const STEPS = ['Bolletta', 'Ripartizione', 'Invio'];
const step = ref(1);

const per = computed(() => props.periodi.find((p) => p.id === props.periodoId) || props.periodi.at(-1));
const incompleto = computed(() => per.value?.stato === 'incompleto');
const mancanti = computed(() => (per.value ? per.value.attese - per.value.presenti : 0));

// Reset to step 1 whenever the period changes.
watch(() => props.periodoId, () => { step.value = 1; });

function goStep(n) {
  if (incompleto.value && n > 1) return; // locked
  step.value = n;
}
</script>

<template>
  <div class="cg">
    <!-- Header -->
    <div class="head">
      <div class="crumbs">
        <span>Utenze &amp; conguagli</span>
        <VpIcon name="chevron" :size="12" />
        <span class="ink">{{ per.label }}</span>
      </div>

      <div class="title-row">
        <div>
          <h1 class="vp-display title">Conguaglio utenze, <span class="title-mese">{{ per.mese }}</span></h1>
          <div class="title-sub">Periodo {{ per.range }} · {{ nInquilini }} inquilini<span v-if="pagataDa"> · pagata da {{ pagataDa }}</span></div>
        </div>

        <PeriodSelector
          :periodi="periodi"
          :model-value="periodoId"
          @update:model-value="(v) => emit('update:periodoId', v)"
        />
      </div>

      <!-- Stepper -->
      <div class="stepper">
        <button
          v-for="(label, i) in STEPS" :key="label"
          class="chip"
          :class="{ active: step === i + 1, done: i + 1 < step, locked: incompleto && i + 1 > 1 }"
          :disabled="incompleto && i + 1 > 1"
          @click="goStep(i + 1)"
        >
          <span class="num">
            <VpIcon v-if="i + 1 < step" name="check" :size="13" :stroke="3" color="#fff" />
            <VpIcon v-else-if="incompleto && i + 1 > 1" name="lock" :size="12" color="var(--vp-ink-3)" />
            <template v-else>{{ i + 1 }}</template>
          </span>
          <span class="chip-text">
            <span class="chip-eyebrow">Passo {{ i + 1 }}</span>
            <span class="chip-label">{{ label }}</span>
          </span>
        </button>
      </div>
    </div>

    <!-- Body -->
    <div class="body vp-scroll">
      <BollettaStep
        v-if="step === 1"
        :periodo="per" :bollette="bollette" :totale="totale"
        @upload="(t) => emit('upload', t)"
      />
      <template v-else-if="step === 2">
        <BloccatoState v-if="incompleto" :mancanti="mancanti" @torna="step = 1" />
        <RipartizioneStep
          v-else
          :criterio="criterio" :quote="quote" :totali-utenza="totaliUtenza"
          :has-nuovo-ingresso="hasNuovoIngresso" :ingresso-nota="ingressoNota"
          @update:criterio="(v) => emit('update:criterio', v)"
        />
      </template>
      <template v-else>
        <BloccatoState v-if="incompleto" :mancanti="mancanti" @torna="step = 1" />
        <InvioStep
          v-else
          :periodo="per" :quote="quote" :criterio="criterio"
          @invia="emit('invia')" @salva-bozza="emit('salva-bozza')"
        />
      </template>
    </div>

    <!-- Footer nav -->
    <div class="foot">
      <button class="vp-btn vp-btn--ghost" :disabled="step === 1" :style="{ opacity: step === 1 ? .4 : 1 }" @click="step = Math.max(1, step - 1)">
        <VpIcon name="back" :size="16" /> Indietro
      </button>

      <div class="foot-status">
        <template v-if="incompleto">Mancano {{ mancanti }} bollette per chiudere {{ per.label }}</template>
        <template v-else-if="step === 1">{{ bollette.length }} bollette lette · totale {{ eur(totale) }}</template>
        <template v-else-if="step === 2">Somma quote {{ eur(quote.reduce((s, q) => s + q.quota, 0)) }} — torna il conto</template>
        <template v-else>{{ quote.length }} avvisi pronti all’invio</template>
      </div>

      <button v-if="incompleto" class="vp-btn vp-btn--primary" @click="emit('upload')">
        <VpIcon name="upload" :size="16" color="#fff" /> Carica le {{ mancanti }} mancanti
      </button>
      <button v-else-if="step < 3" class="vp-btn vp-btn--primary" @click="step = Math.min(3, step + 1)">
        {{ step === 1 ? 'Vai alla ripartizione' : 'Prepara gli avvisi' }} <VpIcon name="arrow" :size="16" color="#fff" />
      </button>
      <button v-else class="vp-btn vp-btn--primary" @click="emit('invia')">
        <VpIcon name="message" :size="16" color="#fff" /> Invia {{ quote.length }} avvisi
      </button>
    </div>
  </div>
</template>

<style scoped>
.cg { width: 100%; height: 100%; display: flex; flex-direction: column; background: var(--vp-paper); color: var(--vp-ink); font-family: var(--vp-font-ui); }
.ink { color: var(--vp-ink); }

.head { padding: 18px 36px 0; flex-shrink: 0; }
.crumbs { display: flex; align-items: center; gap: 8px; font-size: 13px; color: var(--vp-ink-3); }
.title-row { display: flex; justify-content: space-between; align-items: flex-end; margin: 8px 0 16px; flex-wrap: wrap; gap: 12px; }
.title { font-size: 30px; margin: 0; }
.title-mese { color: var(--vp-ink-2); font-style: italic; }
.title-sub { color: var(--vp-ink-2); font-size: 14px; margin-top: 4px; }

.stepper { display: flex; gap: 10px; }
.chip {
  flex: 1; padding: 11px 16px; border-radius: 12px; cursor: pointer; text-align: left;
  background: var(--vp-paper-2); border: 1.5px solid transparent;
  display: flex; align-items: center; gap: 11px; font-family: inherit;
  color: var(--vp-ink-3); transition: background .15s, border-color .15s;
}
.chip.done { background: var(--vp-sage-soft); color: var(--vp-sage-deep); }
.chip.active { background: var(--vp-cream); border-color: var(--vp-terra); color: var(--vp-ink); }
.chip.locked { opacity: .5; cursor: not-allowed; }
.num {
  width: 24px; height: 24px; border-radius: 50%; flex-shrink: 0;
  background: var(--vp-paper-3); color: var(--vp-ink-3);
  display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 600;
}
.chip.done .num { background: var(--vp-sage); color: #fff; }
.chip.active .num { background: var(--vp-terra); color: #fff; }
.chip-text { display: flex; flex-direction: column; }
.chip-eyebrow { font-size: 11px; letter-spacing: 0.06em; text-transform: uppercase; opacity: .7; font-weight: 500; }
.chip-label { font-size: 15px; font-weight: 500; margin-top: 1px; }
.chip.active .chip-label { font-weight: 600; }

.body { flex: 1; min-height: 0; overflow: auto; padding: 20px 36px 96px; }

.foot {
  flex-shrink: 0; padding: 14px 36px; border-top: 1px solid var(--vp-paper-3); background: var(--vp-paper);
  display: flex; align-items: center; justify-content: space-between; gap: 16px;
}
.foot-status { font-size: 13px; color: var(--vp-ink-3); }
</style>
