<script setup>
// STEP 2 · RIPARTIZIONE
// Criterion selector + per-tenant table broken down by utility.
// `quote` is computed by YOUR logic from the selected criterio — this
// component only renders it and emits criterio changes.
import { computed } from 'vue';
import VpIcon from './VpIcon.vue';
import VpAvatar from './VpAvatar.vue';
import { utility, eur, CRITERI } from '../lib/format.js';

const props = defineProps({
  criterio:   { type: String, required: true }, // 'teste' | 'mq' | 'giorni'
  quote:      { type: Array, required: true },   // QuotaInquilino[]
  totaliUtenza:{ type: Object, required: true }, // { Luce, Gas, TARI } period totals
  hasNuovoIngresso: { type: Boolean, default: false }, // show pro-rata note
  ingressoNota:     { type: String, default: '' },
});
const emit = defineEmits(['update:criterio']);

const colTipi = ['Luce', 'Gas', 'TARI'];
const sommaQuote = computed(() => props.quote.reduce((s, q) => s + q.quota, 0));
</script>

<template>
  <div>
    <!-- Criterio -->
    <div class="vp-card crit">
      <div class="sec-head">
        <div class="vp-display" style="font-size:20px">Come dividiamo le utenze?</div>
        <div class="muted">Cambia il criterio, le quote si aggiornano subito.</div>
      </div>
      <div class="crit-grid">
        <button
          v-for="c in CRITERI" :key="c.id"
          class="crit-opt" :class="{ sel: criterio === c.id }"
          @click="emit('update:criterio', c.id)"
        >
          <div class="crit-top"><VpIcon :name="c.icon" :size="16" /><span class="crit-title">{{ c.titolo }}</span></div>
          <div class="crit-sub">{{ c.sub }}</div>
        </button>
      </div>
    </div>

    <!-- Tabella per inquilino -->
    <div class="vp-card tbl-wrap">
      <div class="tbl-head">
        <div class="vp-display" style="font-size:20px">Quota per inquilino</div>
        <span class="muted">Dettaglio Luce · Gas · TARI per persona</span>
      </div>
      <table class="vp-table">
        <thead>
          <tr>
            <th>Inquilino</th>
            <th class="r">{{ criterio === 'mq' ? 'm²' : 'Giorni' }}</th>
            <th class="r" :style="{ color: utility('Luce').fg }">Luce</th>
            <th class="r" :style="{ color: utility('Gas').fg }">Gas</th>
            <th class="r" :style="{ color: utility('TARI').fg }">TARI</th>
            <th class="r">Quota</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="q in quote" :key="q.id ?? q.nome">
            <td>
              <div class="who">
                <VpAvatar :name="q.nome" :size="30" :hue="q.avatarHue" />
                <div><div class="who-name">{{ q.nome }}</div><div class="who-room">{{ q.stanza }}</div></div>
              </div>
            </td>
            <td class="r vp-mono">{{ criterio === 'mq' ? q.mq : q.giorni }}</td>
            <td class="r vp-mono">{{ eur(q.per.Luce) }}</td>
            <td class="r vp-mono">{{ eur(q.per.Gas) }}</td>
            <td class="r vp-mono">{{ eur(q.per.TARI) }}</td>
            <td class="r vp-mono"><span class="quota">{{ eur(q.quota) }}</span></td>
          </tr>
        </tbody>
        <tfoot>
          <tr>
            <td style="font-weight:600">Totale</td>
            <td></td>
            <td class="r vp-mono">{{ eur(totaliUtenza.Luce) }}</td>
            <td class="r vp-mono">{{ eur(totaliUtenza.Gas) }}</td>
            <td class="r vp-mono">{{ eur(totaliUtenza.TARI) }}</td>
            <td class="r vp-mono"><b>{{ eur(sommaQuote) }}</b></td>
          </tr>
        </tfoot>
      </table>
    </div>

    <div v-if="hasNuovoIngresso" class="vp-banner">
      <VpIcon name="clock" :size="18" style="margin-top:2px" />
      <div style="flex:1"><span v-html="ingressoNota"></span></div>
    </div>
  </div>
</template>

<style scoped>
.muted { font-size: 13px; color: var(--vp-ink-3); }
.sec-head { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 14px; }
.crit { padding: 22px 24px; margin-bottom: 16px; }
.crit-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; }
.crit-opt {
  padding: 14px 16px; border-radius: 12px; cursor: pointer; text-align: left;
  background: var(--vp-paper-2); border: 1.5px solid transparent; font-family: inherit; color: var(--vp-ink);
}
.crit-opt.sel { background: var(--vp-terra-soft); border-color: var(--vp-terra); color: var(--vp-terra-deep); }
.crit-top { display: flex; align-items: center; gap: 8px; margin-bottom: 4px; }
.crit-title { font-size: 14px; font-weight: 500; }
.crit-sub { font-size: 12px; color: var(--vp-ink-3); }
.crit-opt.sel .crit-sub { color: var(--vp-terra-deep); }

.tbl-wrap { overflow: hidden; margin-bottom: 16px; }
.tbl-head { padding: 16px 22px; display: flex; justify-content: space-between; align-items: center; }
.r { text-align: right; }
.who { display: flex; align-items: center; gap: 10px; }
.who-name { font-weight: 500; }
.who-room { font-size: 12px; color: var(--vp-ink-3); }
.quota { font-weight: 600; font-size: 15px; }
</style>
