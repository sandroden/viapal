<script setup>
// Period status pill.
//   inviato     → green  "inviato"
//   da-inviare  → honey  "da inviare"
//   incompleto  → clay   "N mancanti"
// `compact` drops the word on the green/honey variants (used inside the
// period selector button where space is tight).
import VpIcon from './VpIcon.vue';

const props = defineProps({
  stato:   { type: String, required: true },   // 'inviato' | 'da-inviare' | 'incompleto'
  mancanti:{ type: Number, default: 0 },
  compact: { type: Boolean, default: false },
});
</script>

<template>
  <span v-if="stato === 'inviato'" class="vp-badge vp-badge--ok">
    <VpIcon name="check" :size="12" :stroke="2.6" />
    <span v-if="!compact">inviato</span>
  </span>

  <span v-else-if="stato === 'da-inviare'" class="vp-badge vp-badge--wait">
    da inviare
  </span>

  <span v-else class="vp-badge vp-badge--late">
    <VpIcon name="alert" :size="12" /> {{ mancanti }} mancanti
  </span>
</template>
