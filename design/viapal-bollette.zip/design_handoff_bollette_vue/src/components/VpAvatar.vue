<script setup>
// Round monogram avatar — initial on a soft, hue-shifted terracotta disc.
// Replace with your real avatar component if you have one; the only thing
// that matters visually is: circle, serif initial, soft warm fill.
const props = defineProps({
  name: { type: String, default: '' },
  size: { type: Number, default: 36 },
  hue:  { type: Number, default: 38 },
});
const initial = (props.name.trim().charAt(0) || '·').toUpperCase();
</script>

<template>
  <div
    class="vp-avatar"
    :style="{
      width: size + 'px', height: size + 'px',
      background: `oklch(0.86 0.05 ${hue})`,
      color: `oklch(0.40 0.08 ${hue})`,
      fontSize: size * 0.45 + 'px',
    }"
  >{{ initial }}</div>
</template>

<style scoped>
.vp-avatar {
  border-radius: 50%;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-family: var(--vp-font-display);
  font-weight: 500;
  flex-shrink: 0;
}
</style>
