<script setup>
import { VP_ICONS } from '../lib/icons.js';

const props = defineProps({
  name:   { type: String, required: true },
  size:   { type: [Number, String], default: 20 },
  color:  { type: String, default: 'currentColor' },
  stroke: { type: [Number, String], default: 1.6 },
});
</script>

<template>
  <svg
    v-if="VP_ICONS[name]"
    :width="size" :height="size" viewBox="0 0 24 24"
    fill="none" :stroke="color" :stroke-width="stroke"
    stroke-linecap="round" stroke-linejoin="round"
    style="flex-shrink: 0"
  >
    <path :d="VP_ICONS[name]" />
  </svg>
</template>
