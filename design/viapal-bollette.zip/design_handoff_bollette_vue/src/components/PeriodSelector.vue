<script setup>
// Period dropdown. Controlled component: pass `periodi`, `modelValue` (the
// selected id) and it emits `update:modelValue`. The default selection rule
// lives in your store (see defaultPeriodoId in lib/format.js).
import { ref, computed } from 'vue';
import VpIcon from './VpIcon.vue';
import StatoBadge from './StatoBadge.vue';

const props = defineProps({
  periodi:    { type: Array, required: true },  // Periodo[]
  modelValue: { type: String, required: true }, // selected id
});
const emit = defineEmits(['update:modelValue']);

const open = ref(false);
const current = computed(() => props.periodi.find((p) => p.id === props.modelValue) || props.periodi.at(-1));
const reversed = computed(() => [...props.periodi].reverse());

function pick(id) {
  emit('update:modelValue', id);
  open.value = false;
}
</script>

<template>
  <div class="wrap">
    <div class="vp-eyebrow" style="margin-bottom:4px">Periodo</div>

    <button class="trigger" @click="open = !open">
      <VpIcon name="calendar" :size="16" color="var(--vp-terra)" />
      <span class="label">{{ current.label }}</span>
      <StatoBadge :stato="current.stato" :mancanti="current.attese - current.presenti" compact />
      <VpIcon name="chevron" :size="15" color="var(--vp-ink-3)" :style="{ transform: open ? 'rotate(90deg)' : 'none', transition: 'transform .15s' }" />
    </button>

    <div v-if="open" class="menu">
      <div class="hint">Si apre sull’ultimo periodo da completare</div>
      <button
        v-for="p in reversed" :key="p.id"
        class="opt" :class="{ sel: p.id === modelValue }"
        @click="pick(p.id)"
      >
        <div class="opt-text">
          <div class="opt-label">{{ p.label }}</div>
          <div class="opt-range">{{ p.range }}</div>
        </div>
        <StatoBadge :stato="p.stato" :mancanti="p.attese - p.presenti" />
      </button>
    </div>
  </div>
</template>

<style scoped>
.wrap { position: relative; }
.trigger {
  display: flex; align-items: center; gap: 10px;
  padding: 9px 14px; border-radius: 11px; cursor: pointer;
  background: var(--vp-paper-2); border: 1.5px solid var(--vp-paper-3);
  font-family: inherit; color: var(--vp-ink); min-width: 210px;
}
.trigger .label { flex: 1; text-align: left; font-weight: 600; font-size: 15px; }
.menu {
  position: absolute; right: 0; top: 100%; margin-top: 6px; z-index: 20; width: 300px;
  background: var(--vp-paper); border: 1px solid var(--vp-paper-3); border-radius: 14px;
  box-shadow: var(--vp-shadow-3); overflow: hidden;
}
.hint { padding: 10px 14px; font-size: 12px; color: var(--vp-ink-3); border-bottom: 1px solid var(--vp-paper-3); }
.opt {
  width: 100%; display: flex; align-items: center; gap: 10px; padding: 11px 14px;
  background: transparent; border: none; cursor: pointer; text-align: left;
  border-left: 3px solid transparent; font-family: inherit; color: var(--vp-ink);
}
.opt.sel { background: var(--vp-cream); border-left-color: var(--vp-terra); }
.opt-text { flex: 1; }
.opt-label { font-size: 14px; font-weight: 500; }
.opt.sel .opt-label { font-weight: 600; }
.opt-range { font-size: 12px; color: var(--vp-ink-3); }
</style>
