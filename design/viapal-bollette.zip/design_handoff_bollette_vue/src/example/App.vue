<script setup>
/*
  Example wiring — shows the data contract the ConguaglioBollette shell
  expects. In your app these refs/computed come from your existing store
  or composables; here they are hard-coded mock values so the component
  renders standalone. Delete this file once integrated.
*/
import { ref, computed } from 'vue';
import ConguaglioBollette from '../components/ConguaglioBollette.vue';
import { defaultPeriodoId } from '../lib/format.js';

// ── Periods ────────────────────────────────────────────────
const periodi = [
  { id: '2025-12', mese: 'dicembre', label: 'Dicembre 2025', range: '01/12 – 31/12', stato: 'inviato',    presenti: 3, attese: 3 },
  { id: '2026-01', mese: 'gennaio',  label: 'Gennaio 2026',  range: '01/01 – 31/01', stato: 'inviato',    presenti: 3, attese: 3 },
  { id: '2026-02', mese: 'febbraio', label: 'Febbraio 2026', range: '01/02 – 28/02', stato: 'inviato',    presenti: 3, attese: 3 },
  { id: '2026-03', mese: 'marzo',    label: 'Marzo 2026',    range: '01/03 – 31/03', stato: 'da-inviare', presenti: 3, attese: 3 },
  { id: '2026-04', mese: 'aprile',   label: 'Aprile 2026',   range: '01/04 – 30/04', stato: 'incompleto', presenti: 1, attese: 3 },
];
const periodoId = ref(defaultPeriodoId(periodi)); // → '2026-04' (most recent open)
const criterio  = ref('giorni');

// ── Bills present for the selected period ──────────────────
// (Your store returns only the bills actually uploaded for periodoId.)
const ALL = {
  '2026-03': [
    { tipo: 'Luce', fornitore: 'Enel Energia', importo: 194.91, periodo: '01/03 – 31/03', consumo: '287 kWh', riferimento: 'POD IT001E94…' },
    { tipo: 'Gas',  fornitore: 'ENI',          importo: 27.02,  periodo: '01/03 – 31/03', consumo: '18 Smc',  riferimento: 'PDR 00980…' },
    { tipo: 'TARI', fornitore: 'Comune',       importo: 44.58,  periodo: '1° trim. 2026', consumo: '—',        riferimento: 'Ruolo 2026' },
  ],
  '2026-04': [
    { tipo: 'Luce', fornitore: 'Enel Energia', importo: 201.40, periodo: '01/04 – 30/04', consumo: '298 kWh', riferimento: 'POD IT001E94…' },
  ],
};
const bollette = computed(() => ALL[periodoId.value] || ALL['2026-03']);
const totale   = computed(() => bollette.value.reduce((s, b) => s + b.importo, 0));
const totaliUtenza = computed(() => {
  const t = { Luce: 0, Gas: 0, TARI: 0 };
  bollette.value.forEach((b) => { t[b.tipo] = b.importo; });
  return t;
});

// ── Tenants + quote split (computed by YOUR logic) ─────────
const INQ = [
  { id: 1, nome: 'Marco', stanza: 'Salvia',   mq: 14, giorni: 31, email: 'marco.b@gmail.com',    avatarHue: 20 },
  { id: 2, nome: 'Sara',  stanza: 'Olmo',     mq: 18, giorni: 31, email: 'sara.conti@gmail.com', avatarHue: 95 },
  { id: 3, nome: 'Leila', stanza: 'Tiglio',   mq: 12, giorni: 31, email: 'leila.h@icloud.com',   avatarHue: 150 },
  { id: 4, nome: 'Yusuf', stanza: 'Acero',    mq: 16, giorni: 31, email: 'yusuf.k@gmail.com',    avatarHue: 250 },
  { id: 5, nome: 'Anna',  stanza: 'Ciliegio', mq: 15, giorni: 18, email: 'anna.r@gmail.com',     avatarHue: 330 },
];
const quote = computed(() => {
  const totMq = INQ.reduce((s, i) => s + i.mq, 0);
  const totG  = INQ.reduce((s, i) => s + i.giorni, 0);
  const n = INQ.length;
  const share = (importo, i) =>
    criterio.value === 'teste' ? importo / n
    : criterio.value === 'mq'  ? importo * i.mq / totMq
    : importo * i.giorni / totG;
  return INQ.map((i) => {
    const per = {};
    bollette.value.forEach((b) => { per[b.tipo] = share(b.importo, i); });
    ['Luce', 'Gas', 'TARI'].forEach((t) => { if (per[t] == null) per[t] = 0; });
    return { ...i, per, quota: Object.values(per).reduce((s, v) => s + v, 0) };
  });
});
const hasNuovoIngresso = computed(() => criterio.value === 'giorni');
const ingressoNota = '<b>Anna è entrata il 14 marzo.</b> Con “pro-rata giorni” paga solo i 18 giorni di presenza: la sua quota scende e si redistribuisce sugli altri.';
</script>

<template>
  <div style="height:100vh">
    <ConguaglioBollette
      v-model:periodo-id="periodoId"
      v-model:criterio="criterio"
      :periodi="periodi"
      :bollette="bollette"
      :totale="totale"
      :quote="quote"
      :totali-utenza="totaliUtenza"
      :n-inquilini="INQ.length"
      pagata-da="Alessandro Dentella"
      :has-nuovo-ingresso="hasNuovoIngresso"
      :ingresso-nota="ingressoNota"
      @upload="(t) => console.log('upload', t)"
      @invia="() => console.log('invia')"
      @salva-bozza="() => console.log('salva bozza')"
    />
  </div>
</template>
