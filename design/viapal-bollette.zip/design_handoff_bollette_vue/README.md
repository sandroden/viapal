# Handoff: Conguaglio bollette (Vue.js)

Reskin/redesign of the **bollette** feature only — the multi-utility expense
split that turns a set of period bills (Luce / Gas / TARI) into per-tenant
charges and notices. **The business logic already exists**; this package is
about the **UI/graphics** layer.

---

## About these files

The visual source of truth is an **HTML/React prototype** built for design
review (`reference/Viapal.html` + `reference/proto-desktop.jsx`, component
`ProtoConguaglio`). It is a *design reference*, not code to ship.

To make integration fast we also ship **ready-to-adapt Vue 3 SFCs**
(`src/components/…`) that recreate the prototype 1:1 using `<script setup>`.
They are **purely presentational**: every number, list and computation is
passed in as props and every action is emitted as an event — so they plug
straight onto your existing store/composables. Treat them as a faithful
starting point; rename/restructure to match your codebase conventions.

> If your app already has a component library (buttons, tables, modals),
> prefer wiring these layouts into *your* primitives over importing the
> sample components wholesale. The tokens + per-view specs below are what
> matter.

## Fidelity

**High-fidelity.** Final colours, typography, spacing, copy and interactions.
Recreate pixel-faithfully. Canvas reference width is **1280px** (desktop,
owner-facing). Layout is responsive via flex/grid; the only fixed pieces are
the sticky header and footer nav.

---

## The feature in one screen

A 3-step wizard inside a single surface (sticky **header** + scrollable
**body** + sticky **footer nav**):

```
┌───────────────────────────────────────────────────────────┐
│ Utenze & conguagli › Aprile 2026                            │
│ Conguaglio utenze, aprile           [📅 Aprile 2026  ▾]     │  ← header (period selector top-right)
│ Periodo 01/04–30/04 · 5 inquilini · pagata da …             │
│ [① Bolletta] [② Ripartizione] [③ Invio]                     │  ← stepper (clickable; locks 2–3 if incomplete)
├───────────────────────────────────────────────────────────┤
│  …active step body (scrolls)…                               │
├───────────────────────────────────────────────────────────┤
│ [‹ Indietro]   status text          [Avanti ›] / [Invia]    │  ← footer nav
└───────────────────────────────────────────────────────────┘
```

### Step 1 · Bolletta  (upload + detail + composition — one merged step)
- **Compact upload strip** (dashed, terracotta): a small fanned stack of
  paper-receipt thumbnails ("scontrini") + a one-line summary + **Aggiungi**
  button. Upload is **multiple** (drag several PDFs at once).
- **Dettaglio delle utenze**: one detail card per utility — coloured header
  (icon + type + supplier), then Periodo / Consumo / Riferimento / Importo,
  footer "PDF letto correttamente".
- **Di cosa si compone**: a segmented proportion bar + legend (each utility's
  amount and % of total) + the period **total**.

### Step 2 · Ripartizione
- **Criterio** selector — 3 cards: *A testa* / *Per stanza (m²)* /
  *Pro-rata giorni*. Changing it re-computes quote instantly (your logic).
- **Quota per inquilino** table: avatar + name + room, the criterion value
  (m² or giorni), then **Luce / Gas / TARI** columns and the **Quota** total
  per tenant; footer row totals each utility and the grand total.
- Optional pro-rata note banner when someone joined mid-period.

### Step 3 · Invio
- **Avvisi agli inquilini**: a list of recipients; each row expands to show
  the exact email/notification preview (amount + per-utility breakdown).
- **Riepilogo invio** card (sticky right): count, total, average, channel,
  **Invia** + **Salva in bozza**.

---

## Period selection (important)

A **period selector** lives top-right in the header (calendar icon + label +
status badge, opens a dropdown of all periods with their status).

**Default rule:** on open, select **the most recent period that is NOT yet
sent _or_ is missing bills** — i.e. the most recent period whose
`stato !== 'inviato'`. See `defaultPeriodoId()` in `src/lib/format.js`.

Period **states** drive the UI:

| `stato`       | meaning                       | badge            | effect on wizard |
|---------------|-------------------------------|------------------|------------------|
| `inviato`     | already sent                  | green "inviato"  | view-only / re-open |
| `da-inviare`  | all bills in, not sent yet    | honey "da inviare" | full flow available |
| `incompleto`  | some bills still missing      | clay "N mancanti" | **steps 2–3 locked**; Bolletta shows present cards + dashed "carica" slots + clay warning |

When a period is `incompleto`, the Bolletta step renders the present detail
cards plus a dashed **upload slot** per missing utility, the composition is
replaced by a clay warning banner, and the stepper chips for Ripartizione &
Invio show a 🔒 and are disabled until the total is complete.

---

## Data contract

Props consumed by `ConguaglioBollette.vue` (provide from your store):

```ts
type Periodo = {
  id: string;          // '2026-03'
  mese: string;        // 'marzo'  (lowercase, used in the title)
  label: string;       // 'Marzo 2026'
  range: string;       // '01/03 – 31/03'
  stato: 'inviato' | 'da-inviare' | 'incompleto';
  presenti: number;    // bills uploaded
  attese: number;      // bills expected (e.g. 3)
};

type Bolletta = {
  tipo: 'Luce' | 'Gas' | 'TARI'; // also keys the colour/icon map
  fornitore: string;             // 'Enel Energia'
  importo: number;               // 194.91
  periodo: string;               // '01/03 – 31/03'
  consumo: string;               // '287 kWh' | '—'
  riferimento: string;           // 'POD IT001E94…'
};

type QuotaInquilino = {
  id: string | number;
  nome: string; stanza: string; email: string;
  mq: number; giorni: number;
  avatarHue: number;                       // 0–360, tints the avatar
  per: { Luce: number; Gas: number; TARI: number }; // quota per utility
  quota: number;                           // sum of `per`
};
```

```
<ConguaglioBollette
  v-model:periodo-id="periodoId"   // String
  v-model:criterio="criterio"      // 'teste' | 'mq' | 'giorni'
  :periodi="Periodo[]"
  :bollette="Bolletta[]"           // ONLY the bills present for the selected period
  :totale="Number"                 // sum of present bills
  :quote="QuotaInquilino[]"
  :totali-utenza="{ Luce, Gas, TARI }"
  :n-inquilini="Number"
  pagata-da="Alessandro Dentella"
  :has-nuovo-ingresso="Boolean"    // show pro-rata note
  :ingresso-nota="String (HTML allowed)"
  @upload="(tipo?) => …"           // user wants to add/upload bills
  @invia="() => …"
  @salva-bozza="() => …"
/>
```

A complete runnable example with mock data is in
`src/example/App.vue` — it documents every field and the default-period rule.

UI-local state owned by the shell (do **not** lift into your store): current
`step`, and which message preview is expanded in Invio.

---

## Design tokens

Full token sheet: `src/styles/tokens.css` (import once, globally). It defines
CSS variables + a handful of utility classes the components rely on
(`vp-card`, `vp-btn`, `vp-badge`, `vp-banner`, `vp-table`, `vp-display`,
`vp-eyebrow`, `vp-mono`). Direction is **"materica"**: warm oat paper, brown
ink (never pure black), terracotta primary, sage/honey/clay status colours.

Key values (all colours are `oklch`):

- **Paper:** `--vp-paper` `0.975 0.012 75` · `--vp-paper-2` `0.945 0.018 75` · `--vp-paper-3` `0.91 0.022 75` · `--vp-cream` `0.985 0.008 80`
- **Ink:** `--vp-ink` `0.26 0.022 50` · `-2` `0.42 0.020 55` · `-3` `0.58 0.018 60` · `-4` `0.78 0.015 70`
- **Terracotta (primary):** `--vp-terra` `0.62 0.115 38` · `--vp-terra-soft` `0.88 0.045 40` · `--vp-terra-deep` `0.45 0.105 35`
- **Sage (ok):** `--vp-sage` `0.58 0.055 145` · soft `0.90 0.030 145` · deep `0.42 0.055 145`
- **Honey (wait):** `--vp-honey` `0.72 0.105 75` · soft `0.92 0.045 80`
- **Clay (error/missing):** `--vp-clay` `0.55 0.110 25` · soft `0.90 0.035 28`
- **Radii:** sm 8 · md 12 · lg 18 · xl 24 · pill 9999 (px)
- **Shadows:** `--vp-shadow-1/2/3` (soft, never hard black)
- **Type:** display `"Source Serif 4", Georgia, serif` · UI `"Geist", system-ui` · mono `"Geist Mono", monospace`. Scale xs12 / sm13 / md15 / lg17 / xl20 / 2xl26 / 3xl34 px.

### Per-utility colour + icon map
Defined in `src/lib/format.js` (`UTILITY`). `fg` = text/accent, `soft` = card
header fill, `bar` = composition segment:

| tipo | icon  | fg                  | soft                 | bar                  |
|------|-------|---------------------|----------------------|----------------------|
| Luce | bolt  | `oklch(0.50 0.10 78)`  | `oklch(0.93 0.05 82)`  | `oklch(0.72 0.105 78)` |
| Gas  | flame | `oklch(0.46 0.07 250)` | `oklch(0.93 0.035 250)`| `oklch(0.62 0.08 250)` |
| TARI | trash | `oklch(0.42 0.055 150)`| `oklch(0.90 0.03 150)` | `oklch(0.58 0.055 150)`|

---

## Interactions & behaviour

- **Stepper chips**: click to jump. Done chip = sage + check; active = cream +
  terracotta border; locked (incomplete period) = dimmed + 🔒, non-clickable.
- **Footer nav**: *Indietro* (disabled on step 1) · centre status text ·
  primary advances (*Vai alla ripartizione* → *Prepara gli avvisi* → *Invia N
  avvisi*). On an incomplete period the primary becomes *Carica le N mancanti*
  and emits `upload`.
- **Period dropdown**: chevron rotates 90° when open; selecting a period
  resets the wizard to step 1 (the shell watches `periodoId`).
- **Criterio cards**: single-select, instant recompute (parent supplies new
  `quote`).
- **Message rows (Invio)**: accordion, one open at a time; chevron rotates.
- **Money**: format with `eur()` (it-IT, 2 decimals, `vp-mono` / tabular-nums).
- **Transitions**: 0.15s ease on backgrounds/borders/transforms. No infinite
  loops. Respect `prefers-reduced-motion`.

---

## The "scontrino" graphic

`src/components/Scontrino.vue` — a cream paper receipt (mono type, dashed
rule, zig-zag torn bottom edge via inline `<svg>`). Two sizes: `mini` (52px,
thumbnails in the upload strip) and full (≈130–150px). Decorative; it
re-states the bill's type + total. Keep it — the client specifically likes it.

---

## Icons

Stroke icons, 24×24 viewBox, `stroke-width≈1.6`. Paths used by this feature
are in `src/lib/icons.js`; rendered by `src/components/VpIcon.vue`. Swap for
your own icon set if you have one — names used: `check, x, arrow, chevron,
back, users, home, clock, message, alert, upload, calendar, lock, bolt,
flame, trash`.

---

## Files in this bundle

```
design_handoff_bollette_vue/
├─ README.md                         ← this file
├─ reference/
│  ├─ Viapal.html                    ← full design canvas (open in a browser)
│  └─ proto-desktop.jsx              ← prototype source; component ProtoConguaglio + CG* views
└─ src/
   ├─ styles/tokens.css              ← design tokens + utility classes (import globally)
   ├─ lib/
   │  ├─ format.js                   ← eur(), UTILITY map, CRITERI, defaultPeriodoId()
   │  └─ icons.js                    ← icon path data
   ├─ components/
   │  ├─ ConguaglioBollette.vue      ← wizard shell (header + stepper + footer)
   │  ├─ PeriodSelector.vue          ← period dropdown
   │  ├─ BollettaStep.vue            ← step 1 (upload + detail + composition / incomplete)
   │  ├─ RipartizioneStep.vue        ← step 2 (criterio + per-tenant table)
   │  ├─ InvioStep.vue               ← step 3 (previews + send summary)
   │  ├─ BloccatoState.vue           ← locked state for steps 2–3
   │  ├─ Scontrino.vue               ← paper-receipt graphic
   │  ├─ StatoBadge.vue              ← period status pill
   │  ├─ VpIcon.vue / VpAvatar.vue   ← primitives
   └─ example/App.vue                ← runnable wiring with mock data (delete after integration)
```

The reference canvas section **"04b · ③ Conguaglio bollette"** holds four
artboards: the default-open state (Aprile, incomplete) plus the three steps
shown on a complete period (Marzo).
