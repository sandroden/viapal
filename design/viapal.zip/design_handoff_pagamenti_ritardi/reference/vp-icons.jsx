/* global React */
// ─────────────────────────────────────────────────────────────
//  Viapal — icone usate dalla schermata "Pagamenti in ritardo".
//  Set ridotto: solo le icone effettivamente referenziate.
//  Uso:  <VPIcon name="wallet" size={20} color="var(--vp-terra)" />
// ─────────────────────────────────────────────────────────────

const VP_ICONS = {
  check:  'M5 13l4 4L19 7',
  bills:  'M4 6h16v12H4zM4 10h16M8 14h2',
  wallet: 'M3 7a2 2 0 0 1 2-2h13v3M3 7v11a2 2 0 0 0 2 2h15V11h-4a2 2 0 0 0 0 4h4',
  leaf:   'M5 21c0-9 6-15 15-15-1 9-6 14-15 15zM5 21l8-8',
  home:   'M3 11.5L12 4l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z',
  chart:  'M4 19V5M4 19h16M8 15v-4M12 15V8M16 15v-7',
  doc:    'M6 3h9l5 5v13H6zM15 3v5h5',
};

function VPIcon({ name, size = 20, color = 'currentColor', stroke = 1.6, fill, style = {} }) {
  const d = VP_ICONS[name];
  if (!d) return null;
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={fill || 'none'}
      stroke={fill ? 'none' : color} strokeWidth={stroke}
      strokeLinecap="round" strokeLinejoin="round"
      style={{ flexShrink: 0, ...style }}>
      <path d={d} />
    </svg>
  );
}

// Esportazione per l'uso senza build (Babel in pagina).
// Con un bundler, sostituisci con:  export { VPIcon };
if (typeof window !== 'undefined') Object.assign(window, { VPIcon });
