/* global React, VPIcon */
// ─────────────────────────────────────────────────────────────
//  Viapal · <TenantHome /> — Home inquilino "pagamenti in ritardo"
//  ---------------------------------------------------------------
//  Due azioni per card: «Paga» (primaria) e «Ho già pagato» (tenue).
//  Spunta i ritardi → li saldi in un unico bonifico (totale in fondo).
//  Donut per i pagamenti parziali.
//
//  DIPENDENZE
//    • React 18
//    • <VPIcon> da vp-icons.jsx
//    • le variabili/classi --vp-* e .vp-btn/.vp-card/.vp-badge…
//      definite in viapal-tokens.css  (importa quel CSS una volta)
//
//  COLLEGAMENTO DATI / AZIONI
//    <TenantHome
//      pagamenti={[...]}                 // tuoi dati (vedi forma sotto)
//      utente={{ nome: 'Diana Carolina' }}
//      onPaga={(p) => ...}               // paga il singolo ritardo
//      onHoPagato={(p) => ...}           // "ho già pagato" → invia estremi
//      onBonificoUnico={(lista, tot) => ...}  // paga i selezionati insieme
//      variant="arioso" | "registro"    // due layout di card
//      desktop={false}                   // griglia 2 col + niente tab bar
//      showRitardo={true}                // mostra/nascondi "giorni di ritardo"
//      stacco="medio"                    // 'soft' | 'medio' | 'forte'
//      showTabBar={true}                 // togli se l'app ha già una sua nav
//    />
//
//  FORMA DI UN PAGAMENTO
//    { id, mese, tot, pagato, ritardo, scad }
//      tot/pagato = numeri (euro). resto = tot - pagato.
//      ritardo = giorni (number). scad = stringa "gg/mm/aaaa".
// ─────────────────────────────────────────────────────────────

// Formatta in stile italiano: 1.234,50
function eur(n) {
  return '€\u00a0' + Number(n).toLocaleString('it-IT', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function resto(p) { return Math.max(0, p.tot - p.pagato); }
function pctPagato(p) { return p.tot ? Math.round((p.pagato / p.tot) * 100) : 0; }

// Dati di esempio — sostituiscili via prop `pagamenti`.
const DEMO_PAGAMENTI = [
  { id: 'lug24', mese: 'Utenze luglio 2024',    tot: 57.04, pagato: 0,     ritardo: 633, scad: '05/09/2024' },
  { id: 'mar25', mese: 'Utenze marzo 2025',     tot: 90.89, pagato: 56.91, ritardo: 391, scad: '05/05/2025' },
  { id: 'giu25', mese: 'Utenze giugno 2025',    tot: 41.10, pagato: 31.87, ritardo: 330, scad: '05/07/2025' },
  { id: 'ago25', mese: 'Utenze agosto 2025',    tot: 38.44, pagato: 0,     ritardo: 268, scad: '05/09/2025' },
  { id: 'set25', mese: 'Utenze settembre 2025', tot: 44.20, pagato: 0,     ritardo: 238, scad: '05/10/2025' },
  { id: 'nov25', mese: 'Utenze novembre 2025',  tot: 51.30, pagato: 0,     ritardo: 176, scad: '05/12/2025' },
  { id: 'gen26', mese: 'Utenze gennaio 2026',   tot: 47.10, pagato: 0,     ritardo: 115, scad: '05/02/2026' },
];

// ── Donut: quanto già versato di un pagamento parziale ────────
function THDonut({ pct, size = 46, stroke = 5 }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const off = c * (1 - pct / 100);
  return (
    <div style={{ position: 'relative', width: size, height: size, flexShrink: 0 }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--vp-paper-3)" strokeWidth={stroke} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--vp-sage)" strokeWidth={stroke}
          strokeDasharray={c} strokeDashoffset={off} strokeLinecap="round" />
      </svg>
      <div style={{
        position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: Math.round(size * 0.27), fontWeight: 600, color: 'var(--vp-sage-deep)',
        fontFamily: 'var(--vp-font-ui)', fontVariantNumeric: 'tabular-nums',
      }}>{pct}%</div>
    </div>
  );
}

// ── Checkbox quadrata morbida ─────────────────────────────────
function THCheck({ on, size = 22 }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: 7, flexShrink: 0,
      border: on ? 'none' : '1.5px solid var(--vp-ink-4)',
      background: on ? 'var(--vp-terra)' : 'transparent',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      transition: 'background .12s, border-color .12s',
    }}>
      {on && <VPIcon name="check" size={Math.round(size * 0.66)} color="var(--vp-cream)" stroke={2.8} />}
    </div>
  );
}

// ── Badge giorni di ritardo (argilla, mai rosso allarme) ──────
function THLate({ giorni }) {
  return (
    <span className="vp-badge vp-badge--late" style={{ height: 22, fontSize: 11.5 }}>
      <span className="vp-dot vp-dot--late" />{giorni} g di ritardo
    </span>
  );
}

// ── CARD — variante «arioso» ──────────────────────────────────
function CardArioso({ p, selected, onToggle, showRitardo, onPaga, onHoPagato }) {
  const parziale = p.pagato > 0;
  const r = resto(p);
  return (
    <div className="vp-card" style={{
      overflow: 'hidden', padding: 0,
      borderColor: selected ? 'var(--vp-terra)' : 'var(--vp-paper-3)',
      boxShadow: selected ? '0 0 0 1px var(--vp-terra), var(--vp-shadow-1)' : 'var(--vp-shadow-1)',
      transition: 'border-color .12s, box-shadow .12s',
    }}>
      <div onClick={onToggle} style={{
        display: 'flex', alignItems: 'center', gap: 12, padding: '14px 16px 0', cursor: 'pointer',
      }}>
        <THCheck on={selected} />
        <div style={{ display: 'flex', alignItems: 'center', gap: 7, color: 'var(--vp-ink-3)' }}>
          <VPIcon name="bills" size={15} color="var(--vp-wood)" />
          <span className="vp-eyebrow" style={{ fontSize: 11 }}>Utenze</span>
        </div>
        <div style={{ flex: 1 }} />
        {showRitardo && <THLate giorni={p.ritardo} />}
      </div>

      <div style={{ padding: '8px 16px 14px' }}>
        <div className="vp-display" style={{ fontSize: 20, marginBottom: 12 }}>{p.mese}</div>

        {parziale ? (
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <THDonut pct={pctPagato(p)} size={52} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="vp-eyebrow" style={{ fontSize: 10.5 }}>Resta da saldare</div>
              <div className="vp-mono" style={{ fontSize: 26, color: 'var(--vp-terra)', lineHeight: 1.1, marginTop: 2 }}>{eur(r)}</div>
              <div style={{ fontSize: 12, color: 'var(--vp-ink-3)', marginTop: 3 }}>
                Versato {eur(p.pagato)} di {eur(p.tot)}
              </div>
            </div>
            <div style={{ textAlign: 'right', fontSize: 12, color: 'var(--vp-ink-3)', alignSelf: 'flex-start' }}>
              Scad.<br />{p.scad}
            </div>
          </div>
        ) : (
          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}>
            <div>
              <div className="vp-eyebrow" style={{ fontSize: 10.5 }}>Importo</div>
              <div className="vp-mono" style={{ fontSize: 26, color: 'var(--vp-terra)', lineHeight: 1.1, marginTop: 2 }}>{eur(p.tot)}</div>
            </div>
            <div style={{ textAlign: 'right', fontSize: 12, color: 'var(--vp-ink-3)' }}>Scad. {p.scad}</div>
          </div>
        )}
      </div>

      <div style={{ display: 'flex', gap: 8, padding: '0 16px 14px' }}>
        <button className="vp-btn vp-btn--primary" style={{ flex: 1, height: 42 }} onClick={() => onPaga && onPaga(p)}>
          {parziale ? 'Salda il resto' : 'Paga'}
        </button>
        <button className="vp-btn vp-btn--ghost" style={{ height: 42, fontSize: 13, fontWeight: 400, color: 'var(--vp-ink-2)' }} onClick={() => onHoPagato && onHoPagato(p)}>
          Ho già pagato
        </button>
      </div>
    </div>
  );
}

// ── CARD — variante «registro» (compatta, da spunta) ──────────
function CardRegistro({ p, selected, onToggle, showRitardo, stacco, onPaga, onHoPagato }) {
  const parziale = p.pagato > 0;
  const r = resto(p);
  const shadow = { soft: 'none', medio: 'var(--vp-shadow-1)', forte: 'var(--vp-shadow-2)' }[stacco] || 'var(--vp-shadow-1)';
  return (
    <div style={{
      background: 'var(--vp-cream)',
      borderRadius: 'var(--vp-r-md)',
      border: '1px solid var(--vp-paper-3)',
      borderLeft: `3px solid ${selected ? 'var(--vp-terra)' : 'transparent'}`,
      boxShadow: selected ? `0 0 0 1px var(--vp-terra), ${shadow === 'none' ? 'var(--vp-shadow-1)' : shadow}` : shadow,
      transition: 'border-color .12s, box-shadow .12s',
      overflow: 'hidden',
    }}>
      <div onClick={onToggle} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '13px 14px', cursor: 'pointer' }}>
        <THCheck on={selected} size={20} />
        {parziale
          ? <THDonut pct={pctPagato(p)} size={38} stroke={4} />
          : <div style={{ width: 38, height: 38, borderRadius: 10, background: 'var(--vp-paper-2)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <VPIcon name="bills" size={18} color="var(--vp-wood)" />
            </div>}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 14.5, fontWeight: 500, color: 'var(--vp-ink)' }}>{p.mese}</div>
          <div style={{ fontSize: 12, color: 'var(--vp-ink-3)', marginTop: 1 }}>
            {parziale ? `Resta ${eur(r)}` : `Scad. ${p.scad}`}
            {showRitardo && <> · <span style={{ color: 'var(--vp-status-late-fg)' }}>{p.ritardo} g di ritardo</span></>}
          </div>
        </div>
        <div className="vp-mono" style={{ fontSize: 17, color: 'var(--vp-terra)', textAlign: 'right' }}>{eur(r)}</div>
      </div>
      <div style={{ display: 'flex', gap: 0, borderTop: '1px solid var(--vp-paper-3)' }}>
        <button style={thRowBtn(true)} onClick={() => onPaga && onPaga(p)}>{parziale ? 'Salda il resto' : 'Paga'}</button>
        <div style={{ width: 1, background: 'var(--vp-paper-3)' }} />
        <button style={thRowBtn(false)} onClick={() => onHoPagato && onHoPagato(p)}>Ho già pagato</button>
      </div>
    </div>
  );
}
function thRowBtn(primary) {
  return {
    flex: primary ? 1.4 : 1, height: 40, border: 'none', cursor: 'pointer',
    background: 'transparent', fontFamily: 'var(--vp-font-ui)',
    fontSize: 13, fontWeight: primary ? 600 : 400,
    color: primary ? 'var(--vp-terra)' : 'var(--vp-ink-3)',
  };
}

// ── Barra totale in fondo (livello contestuale) ───────────────
function TotalBar({ count, total, desktop, onBonificoUnico }) {
  const attivo = count > 0;
  return (
    <div style={{
      borderTop: '1px solid var(--vp-paper-3)',
      background: 'var(--vp-paper)',
      padding: desktop ? '16px 28px' : '12px 16px',
      display: 'flex', alignItems: 'center', gap: 16,
      boxShadow: '0 -6px 20px oklch(0.30 0.02 50 / 0.06)',
    }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div className="vp-eyebrow" style={{ fontSize: 10.5 }}>Totale selezionato</div>
        <div className="vp-display vp-mono" style={{
          fontSize: desktop ? 34 : 27, color: attivo ? 'var(--vp-ink)' : 'var(--vp-ink-4)',
          fontFamily: 'var(--vp-font-display)', letterSpacing: '-0.01em', lineHeight: 1.1, marginTop: 2,
        }}>{eur(total)}</div>
        <div style={{ fontSize: 11.5, color: 'var(--vp-ink-3)', marginTop: 2 }}>
          {attivo ? `${count} ${count === 1 ? 'ritardo' : 'ritardi'} · un unico bonifico` : 'Spunta i ritardi da saldare insieme'}
        </div>
      </div>
      <button className="vp-btn vp-btn--primary" disabled={!attivo} onClick={() => attivo && onBonificoUnico && onBonificoUnico()} style={{
        height: desktop ? 50 : 48, fontSize: 15, minWidth: desktop ? 280 : 0,
        padding: desktop ? '0 28px' : '0 22px', flexShrink: 0,
        opacity: attivo ? 1 : 0.45, cursor: attivo ? 'pointer' : 'not-allowed',
      }}>
        <VPIcon name="wallet" size={18} /> {desktop ? 'Paga con bonifico' : 'Paga'}
      </button>
    </div>
  );
}

// ── Tab bar persistente (rimuovi se la tua app ha già una nav) ─
function VPTabBar() {
  const tabs = [
    { ic: 'home',  label: 'Home',       active: true },
    { ic: 'chart', label: 'Situazione' },
    { ic: 'doc',   label: 'Rendiconto' },
  ];
  return (
    <div style={{
      display: 'flex', borderTop: '1px solid var(--vp-paper-3)',
      background: 'var(--vp-cream)', paddingBottom: 'env(safe-area-inset-bottom)',
    }}>
      {tabs.map((t, i) => (
        <div key={i} style={{
          flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
          padding: '9px 0 11px', cursor: 'pointer',
          color: t.active ? 'var(--vp-terra)' : 'var(--vp-ink-4)',
        }}>
          <VPIcon name={t.ic} size={21} color="currentColor" stroke={t.active ? 2 : 1.7} />
          <span style={{ fontSize: 11, fontWeight: t.active ? 600 : 500 }}>{t.label}</span>
        </div>
      ))}
    </div>
  );
}

// ── Intestazione ──────────────────────────────────────────────
function THHeader({ desktop, pagamenti, utente }) {
  const aperti = pagamenti.length;
  const parziali = pagamenti.filter(p => p.pagato > 0).length;
  return (
    <div style={{ padding: desktop ? '26px 28px 16px' : '6px 18px 14px' }}>
      <div className="vp-eyebrow" style={{ marginBottom: 4 }}>La tua casa</div>
      <div className="vp-display" style={{ fontSize: desktop ? 30 : 25 }}>Ciao, {utente.nome}</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 12, flexWrap: 'wrap' }}>
        <span style={{ fontSize: 14, color: 'var(--vp-ink)' }}>
          <b>{aperti} pagamenti</b> da sistemare
        </span>
        {parziali > 0 && (
          <span className="vp-badge vp-badge--neutral" style={{ height: 22, fontSize: 11.5 }}>
            {parziali} già pagati in parte
          </span>
        )}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
//  COMPONENTE PRINCIPALE
// ─────────────────────────────────────────────────────────────
function TenantHome({
  pagamenti = DEMO_PAGAMENTI,
  utente = { nome: 'Diana Carolina' },
  variant = 'arioso',
  desktop = false,
  showRitardo = true,
  stacco = 'medio',
  showTabBar = true,
  onPaga, onHoPagato, onBonificoUnico,
}) {
  const staccoGap = { soft: 8, medio: 12, forte: 18 }[stacco] || 12;
  const [sel, setSel] = React.useState(() => new Set(pagamenti.map(p => p.id)));
  const toggle = (id) => setSel(prev => {
    const n = new Set(prev);
    n.has(id) ? n.delete(id) : n.add(id);
    return n;
  });
  const allOn = sel.size === pagamenti.length;
  const toggleAll = () => setSel(allOn ? new Set() : new Set(pagamenti.map(p => p.id)));

  const selezionati = pagamenti.filter(p => sel.has(p.id));
  const total = selezionati.reduce((s, p) => s + resto(p), 0);
  const Card = variant === 'registro' ? CardRegistro : CardArioso;

  return (
    <div style={{
      width: '100%', height: '100%', background: 'var(--vp-paper)',
      color: 'var(--vp-ink)', fontFamily: 'var(--vp-font-ui)',
      display: 'flex', flexDirection: 'column', overflow: 'hidden', position: 'relative',
    }}>
      <div className="vp-scroll" style={{ flex: 1, minHeight: 0, overflow: 'auto' }}>
        <div style={{ maxWidth: desktop ? 1040 : 'none', margin: '0 auto' }}>
          <THHeader desktop={desktop} pagamenti={pagamenti} utente={utente} />

          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: desktop ? '0 28px 14px' : '0 18px 12px',
          }}>
            <button onClick={toggleAll} style={{
              display: 'flex', alignItems: 'center', gap: 9, background: 'transparent',
              border: 'none', cursor: 'pointer', padding: '6px 0', fontFamily: 'var(--vp-font-ui)',
              fontSize: 13.5, color: 'var(--vp-ink-2)',
            }}>
              <THCheck on={allOn} size={20} />
              {allOn ? 'Deseleziona tutti' : 'Seleziona tutti'}
            </button>
            <a href="#" onClick={e => e.preventDefault()} style={{
              fontSize: 13, color: 'var(--vp-terra)', textDecoration: 'none', fontWeight: 500,
            }}>Vedi rendiconto →</a>
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: desktop ? '1fr 1fr' : '1fr',
            gap: variant === 'registro' ? staccoGap : staccoGap + 4,
            padding: desktop ? '0 28px 28px' : '0 18px 24px',
          }}>
            {pagamenti.map(p => (
              <Card key={p.id} p={p} selected={sel.has(p.id)} onToggle={() => toggle(p.id)}
                showRitardo={showRitardo} stacco={stacco}
                onPaga={onPaga} onHoPagato={onHoPagato} />
            ))}
          </div>

          <div style={{
            display: 'flex', alignItems: 'flex-start', gap: 10,
            padding: desktop ? '0 28px 24px' : '0 18px 18px',
            color: 'var(--vp-ink-3)', fontSize: 12.5, lineHeight: 1.5,
            maxWidth: desktop ? 620 : 'none',
          }}>
            <VPIcon name="leaf" size={16} color="var(--vp-leaf)" style={{ marginTop: 2, flexShrink: 0 }} />
            <span>Controlla pure i conteggi con calma: se qualcosa non torna, scrivici e lo sistemiamo insieme prima di pagare.</span>
          </div>
        </div>
      </div>

      <TotalBar count={sel.size} total={total} desktop={desktop}
        onBonificoUnico={() => onBonificoUnico && onBonificoUnico(selezionati, total)} />
      {!desktop && showTabBar && <VPTabBar />}
    </div>
  );
}

// Esportazione per l'uso senza build (Babel in pagina).
// Con un bundler, sostituisci con:  export { TenantHome, DEMO_PAGAMENTI };
if (typeof window !== 'undefined') Object.assign(window, { TenantHome, DEMO_PAGAMENTI });
