# Handoff: Home inquilino — “Pagamenti in ritardo”

## Overview
Ridisegno della home dell'inquilino **quando ha pagamenti in ritardo**. Sostituisce la
vecchia schermata (dispersiva, con barra di completamento poco leggibile) con una lista
di pagamenti dove l'inquilino può:

- **spuntare più ritardi** e saldarli in **un unico bonifico** (totale calcolato in fondo);
- per ogni voce, scegliere fra due azioni: **Paga** (primaria) e **Ho già pagato** (secondaria,
  volutamente meno enfatica — serve a notificare gli estremi di un pagamento già effettuato);
- vedere a colpo d'occhio i **pagamenti parziali** tramite un **donut** (% già versata), invece
  della vecchia barra lineare.

Funziona sia su **mobile** che su **desktop**.

## About the Design Files
I file in `reference/` sono **prototipi di design in HTML/React** — servono a *vedere e leggere*
il target (look, struttura, comportamento). **Non sono codice da copiare**: il React qui è solo
una implementazione di riferimento.

➡️ **Il compito è ricostruire questa schermata nell'app Vue esistente**, usando i pattern, i
componenti e le convenzioni già in uso nel vostro codebase (Single File Components `.vue`,
gestione stato, router, ecc.). Prendete da qui i **valori esatti** (colori, spaziature, tipografia,
testi) e i **comportamenti**, e riscriveteli in idiomatica Vue.

Per guardare il riferimento: aprire `reference/index.html` in un browser (mostra mobile “arioso”,
mobile “registro” e desktop affiancati; i click loggano in console).

## Fidelity
**Alta fedeltà (hi-fi).** Colori, tipografia, spaziature e interazioni sono definitivi.
Ricostruire la UI fedelmente usando le librerie/pattern del codebase Vue. Le micro-illustrazioni
sono icone a tratto (stroke) inline — vedere `reference/vp-icons.jsx`.

---

## Screens / Views

### Schermata unica: “Pagamenti in ritardo”
Una sola vista, con due **varianti di layout delle card** (decidere quale adottare — vedi nota in
fondo) e due **superfici** (mobile/desktop).

**Struttura verticale (dall'alto in basso):**
1. **Header** (intestazione gentile)
2. **Barra di selezione** (“Seleziona tutti” + link “Vedi rendiconto →”)
3. **Lista card** dei pagamenti (1 colonna su mobile, 2 colonne su desktop)
4. **Nota gentile** (icona foglia + testo rassicurante)
5. **Barra totale** (livello contestuale, fisso in fondo all'area)
6. **Tab bar** persistente dell'app (solo mobile)

Layout = colonna flex a tutta altezza: l'area 1–4 scorre (`overflow:auto`), mentre 5 e 6 restano
ancorate in fondo (non scrollano).

---

### Componenti

#### 1. Header
- Padding: mobile `6px 18px 14px`, desktop `26px 28px 16px`.
- Occhiello “LA TUA CASA” — classe `.vp-eyebrow` (uppercase, tracking, colore `--vp-ink-3`), `margin-bottom:4px`.
- Titolo “Ciao, {nome}” — font **display** (serif), `font-size` 25px mobile / 30px desktop, colore `--vp-ink`.
- Riga sotto (margin-top 12px, flex, gap 8px, wrap):
  - “**{N} pagamenti** da sistemare” (15px, “{N} pagamenti” in bold).
  - Se ci sono parziali: badge neutro “{N} già pagati in parte” (`.vp-badge .vp-badge--neutral`, height 22, font 11.5px).
- ⚠️ **Rimossa** di proposito la riga “Stanza «…» · canone …” presente nella vecchia home.

#### 2. Barra di selezione
- Flex space-between; padding mobile `0 18px 12px`.
- Sinistra: bottone testuale con checkbox + “Seleziona tutti” / “Deseleziona tutti”
  (toggle: se tutti già selezionati mostra “Deseleziona tutti”). Font 13.5px, colore `--vp-ink-2`.
- Destra: link “Vedi rendiconto →”, colore `--vp-terra`, weight 500, 13px.

#### 3. Checkbox (componente `THCheck`)
- Quadrato arrotondato, `border-radius:7px`.
- **Off**: trasparente, bordo `1.5px solid --vp-ink-4`.
- **On**: fondo `--vp-terra`, niente bordo, dentro un'icona “check” (`--vp-cream`).
- Dimensioni: 22px (card arioso), 20px (registro / “seleziona tutti”).
- Transizione `background .12s, border-color .12s`.

#### 4. Donut pagamento parziale (componente `THDonut`)
- SVG anello, ruotato `-90deg`. Traccia di sfondo `--vp-paper-3`; arco di progresso `--vp-sage`,
  `stroke-linecap:round`. `stroke-dashoffset = circonferenza × (1 − pct/100)`.
- Centro: “{pct}%” — colore `--vp-sage-deep`, weight 600, `font-variant-numeric:tabular-nums`,
  font-size ≈ 27% della dimensione.
- Dimensioni: 52px (card arioso), 38px / stroke 4 (registro).
- **Sostituisce la barra di completamento lineare** — questa era la richiesta esplicita.

#### 5. Badge “giorni di ritardo” (componente `THLate`)
- `.vp-badge .vp-badge--late` (fondo `--vp-status-late-bg` = argilla tenue, testo `--vp-status-late-fg`).
- Pallino (`.vp-dot .vp-dot--late`, colore `--vp-clay`) + “{giorni} g di ritardo”. Height 22, font 11.5px.
- **Tono morbido, mai rosso allarme.** Deve poter essere **nascosto** via opzione (`showRitardo`).

#### 6. Card pagamento — variante “arioso” (`CardArioso`)
Card su classe `.vp-card` (fondo `--vp-cream`, radius `--vp-r-md`=12px, bordo `--vp-paper-3`).
- **Selezionata**: bordo `--vp-terra` + box-shadow `0 0 0 1px --vp-terra, --vp-shadow-1`.
- Click sull'area superiore = toggle selezione.
- Riga top: checkbox · icona “bills” (`--vp-wood`) + occhiello “UTENZE” · (spinge a destra) badge ritardo.
- Titolo `{mese}` in font display, 20px.
- **Se parziale**: donut 52px + “Resta da saldare” (occhiello) + importo resto in **mono** 26px
  `--vp-terra` + “Versato X di Y” (12px) + “Scad. {data}” a destra.
- **Se intero**: “Importo” (occhiello) + importo in mono 26px `--vp-terra`; “Scad. {data}” a destra.
- Azioni (flex, gap 8): **Paga** (`.vp-btn .vp-btn--primary`, flex:1, h42; testo “Salda il resto” se
  parziale) + **Ho già pagato** (`.vp-btn .vp-btn--ghost`, h42, 13px, weight 400, colore `--vp-ink-2`).

#### 7. Card pagamento — variante “registro” (`CardRegistro`) — *preferita dall'utente*
Più compatta, da spunta veloce.
- Contenitore: fondo `--vp-cream`, radius 12px, bordo `--vp-paper-3`, **bordo sinistro 3px**
  (`--vp-terra` se selezionata, altrimenti trasparente). Ombra dipende da `stacco`:
  `soft → none`, `medio → --vp-shadow-1`, `forte → --vp-shadow-2`. Se selezionata aggiunge anche
  `0 0 0 1px --vp-terra`.
- Riga (click = toggle): checkbox 20px · donut 38px **oppure** quadratino 38px con icona “bills” ·
  blocco testo (`{mese}` 14.5px weight 500; sotto, 12px: “Resta {resto}” se parziale altrimenti
  “Scad. {data}”, e se `showRitardo` “ · {giorni} g di ritardo” in colore `--vp-status-late-fg`) ·
  importo resto in mono 17px `--vp-terra` a destra.
- Sotto, riga azioni divisa da bordo top: **Paga/Salda il resto** (flex 1.4, colore `--vp-terra`,
  weight 600) | divisorio 1px | **Ho già pagato** (flex 1, colore `--vp-ink-3`, weight 400). H40, 13px.

#### 8. Nota gentile
- Flex, gap 10, allineata in alto. Icona “leaf” 16px (`--vp-leaf`) + testo 12.5px `--vp-ink-3`,
  line-height 1.5, max-width 620 su desktop.
- Testo: «Controlla pure i conteggi con calma: se qualcosa non torna, scrivici e lo sistemiamo
  insieme prima di pagare.»

#### 9. Barra totale (`TotalBar`) — **il totale sta in fondo, come richiesto**
- Livello contestuale fisso sopra la tab bar. Border-top `--vp-paper-3`, fondo `--vp-paper`,
  box-shadow verso l'alto `0 -6px 20px oklch(0.30 0.02 50 / 0.06)`. Flex align-center, gap 16.
  Padding mobile `12px 16px`, desktop `16px 28px`.
- Sinistra (flex:1): occhiello “TOTALE SELEZIONATO”; importo in **display+mono**, 27px mobile /
  34px desktop (colore `--vp-ink` se >0, altrimenti `--vp-ink-4`); sottotesto 11.5px:
  - se selezione attiva → “{N} ritardo/ritardi · un unico bonifico”
  - se vuota → “Spunta i ritardi da saldare insieme”.
- Destra: bottone **primario** “Paga” (mobile) / “Paga con bonifico” (desktop) con icona “wallet”.
  H48 mobile / 50 desktop. **Disabilitato** (opacity .45, cursor not-allowed) se 0 selezionati.

#### 10. Tab bar (`VPTabBar`) — solo mobile
- Nav persistente dell'app, 3 voci a icona+etichetta: **Home** (attiva), **Situazione**, **Rendiconto**.
- Flex, border-top `--vp-paper-3`, fondo `--vp-cream`, `padding-bottom: env(safe-area-inset-bottom)`.
- Attiva = colore `--vp-terra`, weight 600, stroke icona 2; inattiva = `--vp-ink-4`, weight 500, stroke 1.7.
- ⚠️ La barra totale (#9) è un **livello separato sopra** la tab bar (due livelli distinti, non fusi).
- Se l'app Vue ha già la sua bottom-nav, **non duplicarla**: integrare la barra totale sopra quella esistente
  (nel riferimento è la prop `showTabBar`).
- Icone usate “Situazione/Rendiconto” = grafico/documento generici: **sostituire** con le icone reali
  dell'app se diverse.

---

## Interactions & Behavior
- **Selezione iniziale**: all'apertura **tutti i pagamenti sono selezionati** (si parte dal gesto
  “pago tutto”). Implementare lo stato iniziale come l'insieme di tutti gli `id`.
- **Toggle card**: click sull'area informativa della card → seleziona/deseleziona (NON sui bottoni azione).
- **Seleziona/Deseleziona tutti**: se sono tutti selezionati → svuota; altrimenti → seleziona tutti.
- **Totale**: somma dei **resti** (`tot − pagato`, mai negativo) dei soli selezionati; ricalcolo reattivo.
- **Paga (per card)** → `onPaga(pagamento)`: avvia il pagamento del singolo ritardo.
- **Ho già pagato (per card)** → `onHoPagato(pagamento)`: apre il flusso “notifica estremi pagamento”
  (volutamente secondaria/tenue).
- **Paga con bonifico (barra)** → `onBonificoUnico(selezionati, totale)`: un unico bonifico per i selezionati.
- **Vedi rendiconto →**: naviga al rendiconto (placeholder nel riferimento).
- Transizioni: solo micro-feedback su selezione card/checkbox (`.12s`). Nessuna animazione complessa.
- **Responsive**: mobile = 1 colonna + tab bar; desktop = contenuto centrato max-width 1040px, griglia
  card a 2 colonne, **niente tab bar**, importo totale leggermente più grande.

## State Management
Stato locale del componente:
- `pagamenti: Pagamento[]` (da API/props).
- `selezionati: Set<string>` (id selezionati) — init = tutti gli id.
- Derivati (computed): `total` (somma resti dei selezionati), `allOn` (tutti selezionati?),
  `count` (n. selezionati), `parziali` (pagamenti con `pagato > 0`, per il badge header).
- Opzioni di presentazione (props/config): `variant` ('arioso'|'registro'), `desktop` (bool),
  `showRitardo` (bool), `stacco` ('soft'|'medio'|'forte'), `showTabBar` (bool), `utente.nome`.
- Data fetching: i pagamenti arrivano dal backend (l'utente collega l'API). Nessun fetch nel design.

### Forma dei dati
```ts
type Pagamento = {
  id: string;        // chiave stabile
  mese: string;      // es. "Utenze marzo 2025"
  tot: number;       // importo totale dovuto (euro)
  pagato: number;    // quanto già versato (0 = non pagato; >0 = parziale)
  ritardo: number;   // giorni di ritardo
  scad: string;      // scadenza "gg/mm/aaaa"
};
// resto = max(0, tot - pagato);  pctPagato = round(pagato / tot * 100)
```
Formattazione importi: stile italiano `€ 1.234,50` →
`'€\u00a0' + n.toLocaleString('it-IT', { minimumFractionDigits: 2, maximumFractionDigits: 2 })`.

## Design Tokens
Tutti i token sono in **`reference/viapal-tokens.css`** (variabili CSS `--vp-*` + classi utility
`.vp-btn`, `.vp-card`, `.vp-badge`, `.vp-dot`, `.vp-eyebrow`, `.vp-display`, `.vp-mono`, `.vp-scroll`).
Riusare quel file così com'è (le variabili CSS funzionano identiche in Vue). Valori chiave:

**Colori (oklch)**
- Sfondi: `--vp-paper` 0.975 0.012 75 · `--vp-paper-2` 0.945 0.018 75 · `--vp-paper-3` 0.91 0.022 75 · `--vp-cream` 0.985 0.008 80
- Testo: `--vp-ink` 0.26 0.022 50 · `--vp-ink-2` 0.42 0.020 55 · `--vp-ink-3` 0.58 0.018 60 · `--vp-ink-4` 0.78 0.015 70
- Terracotta (primario): `--vp-terra` 0.62 0.115 38 · `--vp-terra-deep` (hover) 0.45 0.105 35 · `--vp-terra-soft` 0.88 0.045 40
- Salvia (donut/ok): `--vp-sage` 0.58 0.055 145 · `--vp-sage-deep` 0.42 0.055 145
- Argilla (ritardo): `--vp-clay` 0.55 0.110 25 · stato late fg `oklch(0.40 0.110 28)` / bg `--vp-clay-soft` 0.90 0.035 28
- Legno/foglia: `--vp-wood` 0.50 0.045 55 · `--vp-leaf` 0.48 0.075 150

**Tipografia**
- Display (serif): `"Source Serif 4", Georgia, serif`
- UI (sans): `"Geist", system-ui, sans-serif`
- Mono: `"Geist Mono", "SF Mono", Menlo, monospace`
- Scala usata: 11–14.5px testo, 17/20px titoli card, 25–30px titolo header, 26/27/34px importi.

**Radius**: `--vp-r-sm` 8 · `--vp-r-md` 12 · `--vp-r-lg` 18 · `--vp-r-xl` 24 · pill 9999.
**Ombre**: `--vp-shadow-1/2/3` (morbide, mai nere — vedi file).
**Dark mode**: il file include `[data-vp-theme="dark"]` (palette legno scuro) — opzionale.

## Assets
Nessuna immagine bitmap. Icone = SVG a tratto inline in **`reference/vp-icons.jsx`**
(usate: `check, bills, wallet, leaf, home, chart, doc`). In Vue: ricreare come piccoli componenti
icona o usare il set icone già presente nel codebase, mantenendo `stroke-linecap/linejoin: round`,
`viewBox 0 0 24 24`, `stroke-width ≈ 1.6–2`.

## Files
- `reference/index.html` — pagina dimostrativa: apri per vedere mobile (arioso + registro) e desktop.
- `reference/TenantHome.jsx` — implementazione di riferimento (logica, markup, stili inline, props,
  callback). **Da leggere**, non da spedire.
- `reference/vp-icons.jsx` — icone usate.
- `reference/viapal-tokens.css` — design tokens + classi utility (riusabile in Vue).

---

## Nota / decisione aperta
L'utente preferisce la variante **“registro” (compatta)**, possibilmente con **stacco “forte”** fra le
card e **senza** i “giorni di ritardo”. Suggerimento: adottare “registro” come layout di default,
tenendo `showRitardo` come configurazione (alcuni contesti potrebbero volerli mostrare). Confermare
con l'utente prima di rimuovere del tutto il badge ritardo.
